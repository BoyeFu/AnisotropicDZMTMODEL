%This code is used to calculate the coefficient of the strain for inclusion
function STRAININ = STRAININ(Mb,mub,Mc,muc,arflow,arf01,arf02,GAMA01,p,e)
OMIGC01 = OMIGcINFI(Mb,mub,Mc,muc,arflow,arf01,arf02,GAMA01,p);
OMIGCM = ROTAIN(OMIGC01,200);
OMIGC = OMIGCM(1,1)+OMIGCM(1,2)+OMIGCM(1,3);
STRAININ = OMIGC.*e;
end

