%This code is used to show the experiment data
%We use Han's data in gji
clear
%%
Pred = [5	10	15	20	25	30	35	40	45	50];%differential pressure
%%
%SAmple number I 
%%
%P-wave
VpI0 = [3111 3297 3435 3553 3641 3720 3790 3845 3889	3928];%P-wave velocity direction 0
MI0 = [25.64755065	28.80605385	31.26794625	33.45309385	35.13073465	36.67176	38.064865	39.17766625	40.07945065	40.8873376];%P-wave modulus direction 0
VpI45 = [3170	3351	3477	3580	3672	3733	3802	3858	3898	3942];%P-wave velocity direction 45
MI45 = [26.629585	29.75738265	32.03725185	33.96346	35.7314976	36.92851585	38.3062906	39.4430346	40.2651706	41.1793146];%P-wave modulus direction 45
VpI90 = [3197	3376	3507	3618	3699	3771	3834	3882	3919	3951];%P-wave velocity direction 90
MI90 = [27.08514385	30.2030464	32.59247985	34.6882986	36.25889265	37.68416865	38.9538234	39.9352986	40.70018665	41.36756265];%P-wave modulus direction 90
%%
%Sh-wave
VshI0 = [1734	1858	1960	2032	2102	2152	2203	2242	2274	2301];%Sh-wave velocity direction 0
GhI0 = [7.9679034	9.1482346	10.18024	10.9419136	11.7087706	12.2724256	12.86100385	13.3203946	13.7033514	14.03069265];%Shear h modulus direction 0
VshI45 = [1766	1888	1988	2058	2126	2174	2223	2260	2290	2315];%Sh-wave velocity direction 45
GhI45 = [8.2647034	9.4460416	10.4731816	11.2237146	11.9776714	12.5246314	13.09558185	13.53514	13.896865	14.20194625];%Shear h modulus direction 45
VshI90 = [1808	1927	2024	2095	2156	2201	2247	2281	2308	2330];%Sh-wave velocity direction 90
GhI90 = [8.6624896	9.84032185	10.8559264	11.63091625	12.3180904	12.83766265	13.37987385	13.78784665	14.1161896	14.386585];%Shear h modulus direction 90
%%
%SV-wave
VsvI0 = [1764	1881	1978	2048	2117	2167	2207	2246	2275	2302];%SV-wave velocity direction 0
GvI0 = [8.2459944	9.37612665	10.3680826	11.1149056	11.87647585	12.44410585	12.90774985	13.3679674	13.71540625	14.0428906];%Shear V modulus direction 0
VsvI45 = [1745	1870	1967	2041	2110	2161	2210	2243	2276	2296];%SV-wave velocity direction 45
GvI45 = [8.06931625	9.266785	10.25308585	11.03905465	11.798065	12.37529065	12.942865	13.33227985	13.7274664	13.9697824];%Shear V modulus direction 45
VsvI90 = [1761	1884	1981	2052	2121	2175	2211	2244	2270	2300];%SV-wave velocity direction 90
GvI90 = [8.21797065	9.4060584	10.39955665	11.1583656	11.92139865	12.53615625	12.95458065	13.3441704	13.655185	14.0185];%Gv modulus direction 90
%%
%Do linear fitting P-wave
CoePI0 = polyfit(Pred(6:end),MI0(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 0
CoePI45 = polyfit(Pred(6:end),MI45(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 45
CoePI90 = polyfit(Pred(6:end),MI90(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 90
MI0f = polyval(CoePI0,Pred);%the fitting P-wave modulus in direction 0
MI45f = polyval(CoePI45,Pred);%the fitting P-wave modulus in direction 45
MI90f = polyval(CoePI90,Pred);%the fitting P-wave modulus in direction 90
%%
%Do linear fitting Sh-wave
CoeShI0 = polyfit(Pred(6:end),GhI0(6:end),1);%The linear fit coefficent of the  Sh-wave modulus in direction 0
CoeShI45 = polyfit(Pred(6:end),GhI45(6:end),1);%The linear fit coefficent of the  Sh-wave modulus in direction 45
CoeShI90 = polyfit(Pred(6:end),GhI90(6:end),1);%The linear fit coefficent of the  Sh-wave modulus in direction 90
GhI0f = polyval(CoeShI0,Pred);%the fitting Sh-wave modulus in direction 0
GhI45f = polyval(CoeShI45,Pred);%the fitting Sh-wave modulus in direction 45
GhI90f = polyval(CoeShI90,Pred);%the fitting Sh-wave modulus in direction 90
%%
%Do linear fitting SV-wave
CoeSvI0 = polyfit(Pred(6:end),GvI0(6:end),1);%The linear fit coefficent of the  SV-wave modulus in direction 0
CoeSvI45 = polyfit(Pred(6:end),GvI45(6:end),1);%The linear fit coefficent of the  SV-wave modulus in direction 45
CoeSvI90 = polyfit(Pred(6:end),GvI90(6:end),1);%The linear fit coefficent of the  SV-wave modulus in direction 90
GvI0f = polyval(CoeSvI0,Pred);%the fitting SV-wave modulus in direction 0
GvI45f = polyval(CoeSvI45,Pred);%the fitting SV-wave modulus in direction 45
GvI90f = polyval(CoeSvI90,Pred);%the fitting SV-wave modulus in direction 90
%%
%Plot
figure(1)
plot(Pred,MI0)
hold on
plot(Pred,MI45)
hold on
plot(Pred,MI90)
hold on
plot(Pred,MI0f)
hold on
plot(Pred,MI45f)
hold on
plot(Pred,MI90f)
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
%
figure(2)
plot(Pred,GhI0)
hold on
plot(Pred,GhI45)
hold on
plot(Pred,GhI90)
hold on
plot(Pred,GhI0f)
hold on
plot(Pred,GhI45f)
hold on
plot(Pred,GhI90f)
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%
figure(3)
plot(Pred,GvI0)
hold on
plot(Pred,GvI45)
hold on
plot(Pred,GvI90)
hold on
plot(Pred,GvI0f)
hold on
plot(Pred,GvI45f)
hold on
plot(Pred,GvI90f)
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
%Cracked medium
%%
%SAmple number F 
%%
%P-wave
VpF0 = [2904	3098	3248	3378	3479	3572	3654	3728	3791	3842];%P-wave velocity direction 0
MF0 = [22.3480224	25.4336506	27.9561856	30.2388426	32.07411865	33.8118376	35.3820474	36.8296576	38.08495465	39.1165546];%P-wave modulus direction 0
VpF45 = [3062	3244	3384	3497	3599	3675	3749	3815	3865	3912];%P-wave velocity direction 45
MF45 = [24.8459866	27.8873704	30.3463584	32.40687385	34.32492265	35.78990625	37.24575265	38.56869625	39.58629625	40.5549216];%P-wave modulus direction 45
VpF90 = [3189	3350	3483	3596	3679	3753	3818	3868	3907	3941];%P-wave velocity direction 90
MF90 = [26.94976065	29.739625	32.14791585	34.2677224	35.86785865	37.32527385	38.6293786	39.6477736	40.45131985	41.15842465];%P-wave modulus direction 90
%%
%Sh-wave
VshF0 = [1640	1762	1870	1953	2019	2071	2123	2166	2206	2240];%Sh-wave velocity direction 0
GhF0 = [7.12744	8.2273066	9.266785	10.10765385	10.80235665	11.36595865	11.94389185	12.4326234	12.8960554	13.29664];%Shear h modulus direction 0
VshF45 = [1719	1840	1939	2011	2075	2124	2172	2213	2248	2279];%Sh-wave velocity direction 45
GhF45 = [7.83064665	8.97184	9.96326065	10.71692065	11.40990625	11.9551464	12.5015976	12.97802785	13.3917856	13.76367865];%Shear h modulus direction 45
VshF90 = [1781	1900	1990	2059	2120	2169	2211	2250	2281	2307];%Sh-wave velocity direction 90
GhF90 = [8.40569665	9.5665	10.494265	11.23462465	11.91016	12.46708665	12.95458065	13.415625	13.78784665	14.10395985];%Shear h modulus direction 90
%%
%SV-wave
VsvF0 = [1635	1760	1869	1950	2017	2070	2121	2164	2205	2238];%SV-wave velocity direction 0
GvF0 = [7.08404625	8.20864	9.25687665	10.076625	10.78096585	11.354985	11.92139865	12.4096744	12.88436625	13.2729066];%Shear V modulus direction 0
VsvF45 = [1693	1820	1919	1991	2055	2104	2156	2199	2239	2269];%SV-wave velocity direction 45
GvF45 = [7.59555985	8.77786	9.75878665	10.50481465	11.19101625	11.7310624	12.3180904	12.81434265	13.28477065	13.64315665];%Shear V modulus direction 45
VsvF90 = [1653	1779	1880	1959	2026	2076	2125	2170	2209	2242];%SV-wave velocity direction 90
GvF90 = [7.24088385	8.38682865	9.36616	10.16985465	10.8773914	11.4209064	11.96640625	12.478585	12.93115465	13.3203946];%Gv modulus direction 90
%%
%Do linear fitting P-wave
CoePF0 = polyfit(Pred(6:end),MF0(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 0
CoePF45 = polyfit(Pred(6:end),MF45(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 45
CoePF90 = polyfit(Pred(6:end),MF90(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 90
MF0f = polyval(CoePF0,Pred);%the fitting P-wave modulus in direction 0
MF45f = polyval(CoePF45,Pred);%the fitting P-wave modulus in direction 45
MF90f = polyval(CoePF90,Pred);%the fitting P-wave modulus in direction 90
%%
%Do linear fitting Sh-wave
CoeShF0 = polyfit(Pred(6:end),GhF0(6:end),1);%The linear fit coefficent of the  Sh-wave modulus in direction 0
CoeShF45 = polyfit(Pred(6:end),GhF45(6:end),1);%The linear fit coefficent of the  Sh-wave modulus in direction 45
CoeShF90 = polyfit(Pred(6:end),GhF90(6:end),1);%The linear fit coefficent of the  Sh-wave modulus in direction 90
GhF0f = polyval(CoeShF0,Pred);%the fitting Sh-wave modulus in direction 0
GhF45f = polyval(CoeShF45,Pred);%the fitting Sh-wave modulus in direction 45
GhF90f = polyval(CoeShF90,Pred);%the fitting Sh-wave modulus in direction 90
%%
%Do linear fitting SV-wave
CoeSvF0 = polyfit(Pred(6:end),GvF0(6:end),1);%The linear fit coefficent of the  SV-wave modulus in direction 0
CoeSvF45 = polyfit(Pred(6:end),GvF45(6:end),1);%The linear fit coefficent of the  SV-wave modulus in direction 45
CoeSvF90 = polyfit(Pred(6:end),GvF90(6:end),1);%The linear fit coefficent of the  SV-wave modulus in direction 90
GvF0f = polyval(CoeSvF0,Pred);%the fitting SV-wave modulus in direction 0
GvF45f = polyval(CoeSvF45,Pred);%the fitting SV-wave modulus in direction 45
GvF90f = polyval(CoeSvF90,Pred);%the fitting SV-wave modulus in direction 90
%%
%Plot
figure(4)
plot(Pred,MF0)
hold on
plot(Pred,MF45)
hold on
plot(Pred,MF90)
hold on
plot(Pred,MF0f)
hold on
plot(Pred,MF45f)
hold on
plot(Pred,MF90f)
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
%
figure(5)
plot(Pred,GhF0)
hold on
plot(Pred,GhF45)
hold on
plot(Pred,GhF90)
hold on
plot(Pred,GhF0f)
hold on
plot(Pred,GhF45f)
hold on
plot(Pred,GhF90f)
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%
figure(6)
plot(Pred,GvF0)
hold on
plot(Pred,GvF45)
hold on
plot(Pred,GvF90)
hold on
plot(Pred,GvF0f)
hold on
plot(Pred,GvF45f)
hold on
plot(Pred,GvF90f)
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')