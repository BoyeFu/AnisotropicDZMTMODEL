function [QLINEAR,GLINEAR,cbb] = DLINEAR(Qb,Gb,Mb,mub,Mc,muc,PHI11,PHI12,arflow,arflow02,arf02,GAMA01,p,e,NMAX)
%%
Kpb = Qb-4./3.*Gb;
vpb=(Qb-2*Gb)/(2*(Qb-Gb)); %Poisson ratio
Lamdab = Qb-2.*Gb;
Db = [Qb Lamdab Lamdab 0 0 0;Lamdab Qb Lamdab 0 0 0;Lamdab Lamdab Qb 0 0 0;0 0 0 Gb 0 0;0 0 0 0 Gb 0;0 0 0 0 0 Gb];
%The integration of arelow02
x2=1;%the high limit of the integration
x1=arflow02;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
m=(NMAX+1)/2;%%？
xm=(x2+x1)/2;%midpoint 
xl=(x2-x1)/2;%midpoint
NN=xm;
MM=xl;
for i=1:m
Z=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z1=Z-1;%0>Z1>-1
ZZ(floor(i))=Z;
ZZZ(i)=Z-Z1;
while (Z-Z1) > 3d-14
p1=1;
p2=0;
for j=1:NMAX
p3=p2;
p2=p1;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p1=((2*j-1)*Z*p2-(j-1)*p3)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(Z*p1-p2)/(Z^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z1=Z;
Z=Z1-p1/pp;
end
x(i)=xm-xl*Z;%x1<x<(x2+x1)/2
x(NMAX+1-i)=xm+xl*Z;%x2>x>(x2+x1)/2
w(i)=2*xl/((1-Z^2)*pp^2);%(x2-x1)/2
w(NMAX+1-i)=w(i);
end
for i=1:NMAX
u(i)=x(i);
end
%%
%The discreatation of arelow
x22=1;%the high limit of the integration
x11=arflow;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
mm=(NMAX+1)/2;%%？
xmm=(x22+x11)/2;%midpoint 
xll=(x22-x11)/2;%midpoint
NN=xmm;
MM=xll;
for i=1:mm
ZS=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z11=ZS-1;%0>Z1>-1
ZZ1(floor(i))=ZS;
ZZZ1(i)=ZS-Z11;
while (ZS-Z11) > 3d-14
p11=1;
p22=0;
for j=1:NMAX
p33=p22;
p22=p11;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p11=((2*j-1)*ZS*p22-(j-1)*p33)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(ZS*p11-p22)/(ZS^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z11=ZS;
ZS=Z11-p11/pp;
end
y(i)=xmm-xll*ZS;%x1<x<(x2+x1)/2
y(NMAX+1-i)=xmm+xll*ZS;%x2>x>(x2+x1)/2
q(i)=2*xll/((1-ZS^2)*pp^2);%(x2-x1)/2
q(NMAX+1-i)=q(i);
end
for i=1:NMAX
v(i)=y(i);
end
%%
%the fracture porosity
for I=1:NMAX
cc(I)=(pi.^2.*Kpb.*(1-2.*vpb).*v(I).*GAMA01./((1-vpb.^2).*p).*exp(-(3.*pi.*Kpb.*(1-2.*vpb).*(v(I)))./(4.*(1-vpb.^2).*p))).*(1-arf02./v(I)).*q(I);
end
cbb = 1-sum(cc);
%Calculate the elastic modulus
DcIF11 = zeros(1,NMAX);
DcIF66 = zeros(1,NMAX);
for I=1:NMAX
E = STRAININ(Mb,mub,Mc,muc,arflow,u(I),arf02,GAMA01,p,e);
Qc = Mc+PHI11.*E;
Gc = muc+PHI12.*E;
Lamdac = Qc-2.*Gc;
Dc = [Qc Lamdac Lamdac 0 0 0;Lamdac Qc Lamdac 0 0 0;Lamdac Lamdac Qc 0 0 0;0 0 0 Gc 0 0;0 0 0 0 Gc 0;0 0 0 0 0 Gc];
DcIFM = (pi.^2.*Kpb.*(1-2.*vpb).*u(I).*GAMA01./((1-vpb.^2).*p).*exp(-(3.*pi.*Kpb.*(1-2.*vpb).*(u(I)))./(4.*(1-vpb.^2).*p))).*(1-arf02./u(I)).*Dc.*w(I);
DcIF11(I) = DcIFM(1,1);
% DcIF12(I) = CcIFM(1,2);
% DcIF13(I) = CcIFM(1,3);
% DcIF21(I) = CcIFM(2,1);
% DcIF22(I) = CcIFM(2,2);
% DcIF23(I) = CcIFM(2,3);
% DcIF31(I) = CcIFM(3,1);
% DcIF32(I) = CcIFM(3,2);
% DcIF33(I) = CcIFM(3,3);
% DcIF44(I) = CcIFM(4,4);
% DcIF55(I) = CcIFM(5,5);
DcIF66(I) = DcIFM(6,6);
end
DcM11=sum(DcIF11);
% DcM12=sum(DcIF12);
% DcM13=sum(DcIF13);
% DcM21=sum(DcIF21);
% DcM22=sum(DcIF22);
% DcM23=sum(DcIF23);
% DcM31=sum(DcIF31);
% DcM32=sum(DcIF32);
% DcM33=sum(DcIF33);
% DcM44=sum(DcIF44);
% DcM55=sum(DcIF55);
DcM66=sum(DcIF66);
%DcL=[DcM11 DcM12 DcM13 0 0 0;DcM21 DcM22 DcM23 0 0 0;DcM31 DcM32 DcM33 0 0 0;0 0 0 DcM44 0 0;0 0 0 0 DcM55 0;0 0 0 0 0 DcM66];
%DLINEAR = sumffcb.*Db+DcL;
QLINEAR = DcM11;
GLINEAR = DcM66;
end