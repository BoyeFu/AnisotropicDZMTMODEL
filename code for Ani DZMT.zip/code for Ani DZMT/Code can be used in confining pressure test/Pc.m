%This function will beused to calculate P
function Pc = Pc(Mb,mub,arf01,arf02)
arf = arf01-arf02;%The aspect ratio
g = arf./((1-arf.^2).^(3/2)).*(acos(arf)-arf.*sqrt(1-arf.^2));
vb=(Mb-2*mub)/(2*(Mb-mub));
P11 = 1./(2.*mub.*(1-vb)).*((1-2.*vb)+arf.^2./(arf.^2-1))+1./(4.*mub.*(1-vb)).*(4.*(vb-1)-3./(arf.^2-1)).*g;
P22 = 3./(16.*mub.*(1-vb)).*(arf.^2./(arf.^2-1))+1./(32.*mub.*(1-vb)).*(4.*(1-4.*vb)-9./(arf^2-1)).*g;
P33 = P22;
P66 = -1./(4.*mub.*(1-vb)).*(vb+1./(arf.^2-1))+1./(8.*mub.*(1-vb)).*((1+vb)+3./(arf.^2-1)).*g;
P55 = P66;
P44 = 1./(16.*mub.*(1-vb)).*arf.^2./(arf.^2-1)+1./(32.*mub.*(1-vb)).*(4.*(1-2.*vb)-3./(arf.^2-1)).*g;
P12 = -1./(4.*mub.*(1-vb)).*arf.^2./(arf.^2-1)+1./(8.*mub.*(1-vb)).*((1+2.*arf.^2)./(arf.^2-1)).*g;
P13 = P12;
P21 = P12;
P31 = P13;
P23 = 1./(16.*mub.*(1-vb)).*arf.^2./(arf.^2-1)+1./(32.*mub.*(1-vb)).*((1-4.*arf.^2)./(arf.^2-1)).*g;
P32 = P23;
Pc = [P11 P12 P13 0 0 0;P21 P22 P23 0 0 0;P31 P32 P33 0 0 0;0 0 0 2*P44 0 0;0 0 0 0 2*P55 0;0 0 0 0 0 2*P66];
end