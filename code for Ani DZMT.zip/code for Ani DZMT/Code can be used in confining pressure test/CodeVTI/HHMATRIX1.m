%The sries of function is used to calculate the P matrix when the
%background meidum is a VTI medium (C11=C22 C23=C13 C44=C55)
%The function is made from Effective elastic modulus of a transverse isotropy solid with aligned inhomogeneity Xu Song Tang Xiao-Ming Su Yuan-Da Citation: Acta Physica Sinica, 64, 206201 (2015) DOI: 10.7498/aps.64.206201
%The code is used to calculate H/a^3/D matrx,the result is a 6*6 matrix
%a1 = a2 = r, a3/a = gama,aspect ratio
function HaD = HHMATRIX1(C,x,y,z,r,gama)
HaD = zeros(6,6);
a3 = r;
a2 = a3;
a1 = gama*r;
a = sqrt((a1.*x).^2+(a2.*y).^2+(a3.*z).^2);
[N,D] = NMATRIX1(C,x,y,z);
H11 = 4.*N(1,1).*x.^2;
H22 = 4.*N(2,2).*y.^2;
H33 = 4.*N(3,3).*z.^2;
H12 = 4.*N(1,2).*x.*y;
H21 = H12;
H13 = 4.*N(1,3).*x.*z;
H31 = H13;
H23 = 4.*N(2,3).*y.*z;
H32 = H23;
H44 = 2.*N(2,3).*y.*z+N(2,2).*z.^2+N(3,3).*y.^2;
H55 = 2.*N(1,3).*x.*z+N(3,3).*x.^2+N(1,1).*z.^2;
H66 = 2.*N(1,2).*x.*y+N(1,1).*y.^2+N(2,2).*x.^2;
HaD(1,1) = a1.*a2.*a3./4./pi.*H11./(a.^3)./D;
HaD(2,2) = a1.*a2.*a3./4./pi.*H22./(a.^3)./D;
HaD(3,3) = a1.*a2.*a3./4./pi.*H33./(a.^3)./D;
HaD(1,2) = a1.*a2.*a3./4./pi.*H12./(a.^3)./D;
HaD(1,3) = a1.*a2.*a3./4./pi.*H13./(a.^3)./D;
HaD(2,1) = a1.*a2.*a3./4./pi.*H21./(a.^3)./D;
HaD(2,3) = a1.*a2.*a3./4./pi.*H23./(a.^3)./D;
HaD(3,1) = a1.*a2.*a3./4./pi.*H31./(a.^3)./D;
HaD(3,2) = a1.*a2.*a3./4./pi.*H32./(a.^3)./D;
HaD(4,4) = a1.*a2.*a3./4./pi.*H44./(a.^3)./D;
HaD(5,5) = a1.*a2.*a3./4./pi.*H55./(a.^3)./D;
HaD(6,6) = a1.*a2.*a3./4./pi.*H66./(a.^3)./D;
end




