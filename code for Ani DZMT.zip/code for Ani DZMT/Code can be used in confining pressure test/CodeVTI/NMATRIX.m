%The sries of function is used to calculate the P matrix when the
%background meidum is a VTI medium (C11=C22 C23=C13 C44=C55)
%The function is made from Effective elastic modulus of a transverse isotropy solid with aligned inhomogeneity Xu Song Tang Xiao-Ming Su Yuan-Da Citation: Acta Physica Sinica, 64, 206201 (2015) DOI: 10.7498/aps.64.206201
%The code is used to calculate N matrx
function [N,D] = NMATRIX(C,x,y,z)
%C is the background stiffness matrix 6*6, x y z are the variable
N = zeros(3,3);
n = sqrt(x.^2+y.^2);
N(1,1) = (C(6,6).*x.^2+C(1,1).*y.^2+C(4,4).*z.^2).*(C(4,4).*n.^2+C(3,3).*z.^2)-(C(1,3)+C(4,4)).^2.*y.^2.*z.^2;
N(2,2) = (C(1,1).*x.^2+C(6,6).*y.^2+C(4,4).*z.^2).*(C(4,4).*n.^2+C(3,3).*z.^2)-(C(1,3)+C(4,4)).^2.*x.^2.*z.^2;
N(3,3) = (C(1,1).*x.^2+C(6,6).*y.^2+C(4,4).*z.^2).*(C(6,6).*x.^2+C(1,1).*y.^2+C(4,4).*z.^2)-(C(1,1)-C(6,6)).^2.*x.^2.*y.^2;
N(1,2) = (C(1,3)+C(4,4)).^2.*x.*y.*z.^2-(C(1,1)-C(6,6)).*x.*y.*(C(4,4).*n.^2+C(3,3).*z.^2);
N(2,1) = N(1,2);
N(1,3) = (C(1,1)-C(6,6)).*(C(1,3)+C(4,4)).*x.*y.^2.*z-(C(1,3)+C(4,4)).*x.*z.*(C(6,6).*x.^2+C(1,1).*y.^2+C(4,4).*z.^2);
N(3,1) = N(1,3);
N(2,3) = (C(1,1)-C(6,6)).*(C(1,3)+C(4,4)).*x.^2.*y.*z-(C(1,3)+C(4,4)).*y.*z.*(C(1,1).*x.^2+C(6,6).*y.^2+C(4,4).*z.^2);
N(3,2) = N(2,3);
D = (C(6,6).*n.^2+C(4,4).*z.^2).*((C(4,4).*n.^2+C(3,3).*z.^2).*(C(1,1).*n.^2+C(4,4).*z.^2)-(C(1,3)+C(4,4)).^2.*n.^2.*z.^2);
end
