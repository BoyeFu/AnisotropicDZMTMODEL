%This code is used to calculate the stress denpendent velocity for the
%experiment data
clear
%we want to calculate the calculation time
tic
%%
%Basic parameters
%The parameters for quatz
Kgr = 37; %Bulk modulus of quatz
mugr = 44; %Shear modulus of quatz
Mca = 0;%the P-wave modulus of air unit GPa
muca = 0;%Shear modulus of aire
Mcw = 2.25;%The P-wave modulus (bulk modulus) of water
mucw = 0;%Shear moudlus of water
p = 7.5/1000;%unit MPa
GAMAI01 = 0.35;%the initial
NMAXI = 500;
pF = 25/1000;%unit MPa
GAMAF01 = 0.05;%the initial
NMAXF = 500;
%%
%Load experiment data
%%
%P-wave modulus
MI0 = [25.64755065	28.80605385	31.26794625	33.45309385	35.13073465	36.67176	38.064865	39.17766625	40.07945065	40.8873376];%P-wave modulus direction 0
MI45 = [26.629585	29.75738265	32.03725185	33.96346	35.7314976	36.92851585	38.3062906	39.4430346	40.2651706	41.1793146];%P-wave modulus direction 45
MI90 = [27.08514385	30.2030464	32.59247985	34.6882986	36.25889265	37.68416865	38.9538234	39.9352986	40.70018665	41.36756265];%P-wave modulus direction 90
MeI = 1/3.*(MI0+MI45+MI90);%The effective P-wave modulus
%%
%Shear modulus
GhI0 = [7.9679034	9.1482346	10.18024	10.9419136	11.7087706	12.2724256	12.86100385	13.3203946	13.7033514	14.03069265];%Shear h modulus direction 0
GhI45 = [8.2647034	9.4460416	10.4731816	11.2237146	11.9776714	12.5246314	13.09558185	13.53514	13.896865	14.20194625];%Shear h modulus direction 45
GhI90 = [8.6624896	9.84032185	10.8559264	11.63091625	12.3180904	12.83766265	13.37987385	13.78784665	14.1161896	14.386585];%Shear h modulus direction 90
GvI0 = [8.2459944	9.37612665	10.3680826	11.1149056	11.87647585	12.44410585	12.90774985	13.3679674	13.71540625	14.0428906];%Shear V modulus direction 0
GvI45 = [8.06931625	9.266785	10.25308585	11.03905465	11.798065	12.37529065	12.942865	13.33227985	13.7274664	13.9697824];%Shear V modulus direction 45
GvI90 = [8.21797065	9.4060584	10.39955665	11.1583656	11.92139865	12.53615625	12.95458065	13.3441704	13.655185	14.0185];%Gv modulus direction 90
GeI = 1/6.*(GhI0+GhI45+GhI90+GvI0+GvI45+GvI90);%The effective P-wave modulus
%%
Pred = [5	10	15	20	25	30	35	40	45	50];%differential pressure
%%
%Do linear fitting P-wave
CoePI0 = polyfit(Pred(6:end),MI0(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 0
CoePI45 = polyfit(Pred(6:end),MI45(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 45
CoePI90 = polyfit(Pred(6:end),MI90(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 90
%%
%Do linear fitting Sh-wave
CoeShI0 = polyfit(Pred(6:end),GhI0(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 0
CoeShI45 = polyfit(Pred(6:end),GhI45(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 45
CoeShI90 = polyfit(Pred(6:end),GhI90(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 90
%%
%Do linear fitting SV-wave
CoeSvI0 = polyfit(Pred(6:end),GvI0(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 0
CoeSvI45 = polyfit(Pred(6:end),GvI45(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 45
CoeSvI90 = polyfit(Pred(6:end),GvI90(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 90
%%
% CoePI = 1/3.*(CoePI0+CoePI45+CoePI90);
% CoeSI = 1/6.*(CoeShI0+CoeShI45+CoeShI90+CoeSvI0+CoeSvI45+CoeSvI90);
CoePI = polyfit(Pred(6:end),MeI(6:end),1);
CoeSI = polyfit(Pred(6:end),GeI(6:end),1);
MbI = CoePI(2);%The P-wave modulus when the pressure is zero
mubI = CoeSI(2);%The background shear modulus when the pressure is zero
KbI = MbI-4./3.*mubI;%The bulk moudulus of background medium when the pressure is at zero
vbI=(MbI-2.*mubI)./(2.*(MbI-mubI)); %Poisson ratio
%%
%%
%we will model the elastic modulus variation of the dry sample
LE = length(Pred);%The length of strain, and for every strain, we will have a increase of the elastic moduli
are02I = 4.*(1-vbI.^2)./(3.*pi.*KbI.*(1-2.*vbI)).*Pred/1000;
% Qb = zeros(1,LE);
% Gb = zeros(1,LE);
%%
%The background medium elastic moduli
QbI = polyval(CoePI,Pred);
GbI = polyval(CoeSI,Pred);
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
QcainI = zeros(1,LE);
GcainI = zeros(1,LE);
QcrI = zeros(1,LE);
GcrI = zeros(1,LE);
phiccI = zeros(1,LE);
phibbI = zeros(1,LE);
parfor II = 1:LE
%     [Qcain(II),Gcain(II),Qcr(II),Gcr(II)] = DINSTRAININ(Qb(II),Gb(II),Mb,mub,Mca,muca,PHI11ca,PHI12ca,are02(II),are02(II),are02(II),GAMA01,p,e(II),NMAX);
    [QcainI(II),GcainI(II),QcrI(II),GcrI(II),phibbI(II),phiccI(II)] = DINSTRAININ(QbI(II),GbI(II),MbI,mubI,Mca,muca,0,0,are02I(II),are02I(II),are02I(II),GAMAI01,p,0,NMAXI);
end
QdI = QbI+QcainI;%The elastic modulus of dry sample P-wave modulus
GdI = GbI+GcainI;%The elastic modulus of dry sample Shear modulus
%%
%%
%Aligend crack influence
%%
%P-wave modulus
MF0 = [22.3480224	25.4336506	27.9561856	30.2388426	32.07411865	33.8118376	35.3820474	36.8296576	38.08495465	39.1165546];%P-wave modulus direction 0
MF45 = [24.8459866	27.8873704	30.3463584	32.40687385	34.32492265	35.78990625	37.24575265	38.56869625	39.58629625	40.5549216];%P-wave modulus direction 45
MF90 = [26.94976065	29.739625	32.14791585	34.2677224	35.86785865	37.32527385	38.6293786	39.6477736	40.45131985	41.15842465];%P-wave modulus direction 90
%%
%Shear modulus
GhF0 = [7.12744	8.2273066	9.266785	10.10765385	10.80235665	11.36595865	11.94389185	12.4326234	12.8960554	13.29664];%Shear h modulus direction 0
GhF45 = [7.83064665	8.97184	9.96326065	10.71692065	11.40990625	11.9551464	12.5015976	12.97802785	13.3917856	13.76367865];%Shear h modulus direction 45
GhF90 = [8.40569665	9.5665	10.494265	11.23462465	11.91016	12.46708665	12.95458065	13.415625	13.78784665	14.10395985];%Shear h modulus direction 90
GvF0 = [7.08404625	8.20864	9.25687665	10.076625	10.78096585	11.354985	11.92139865	12.4096744	12.88436625	13.2729066];%Shear V modulus direction 0
GvF45 = [7.59555985	8.77786	9.75878665	10.50481465	11.19101625	11.7310624	12.3180904	12.81434265	13.28477065	13.64315665];%Shear V modulus direction 45
GvF90 = [7.24088385	8.38682865	9.36616	10.16985465	10.8773914	11.4209064	11.96640625	12.478585	12.93115465	13.3203946];%Gv modulus direction 90
%%
KbF = QdI-4./3.*GdI;%The bulk moudulus of background medium when the pressure is at zero
vbF=(QdI-2.*GdI)./(2.*(QdI-GdI)); %Poisson ratio
are02F = 4.*(1-vbF.^2)./(3.*pi.*KbF.*(1-2.*vbF)).*Pred/1000;
QbF = real(QdI);
GbF = real(GdI);
LE = length(QbF);
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
Qc11F = zeros(1,LE);
Qc22F = zeros(1,LE);
Qc33F = zeros(1,LE);
Gc44F = zeros(1,LE);
Gc55F = zeros(1,LE);
Gc66F = zeros(1,LE);
parfor III = 1:LE
%     [Qcain(II),Gcain(II),Qcr(II),Gcr(II)] = DINSTRAININ(Qb(II),Gb(II),Mb,mub,Mca,muca,PHI11ca,PHI12ca,are02(II),are02(II),are02(II),GAMA01,p,e(II),NMAX);
    [Qc11F(III),Qc22F(III),Qc33F(III),Qc12F(III),Qc13F(III),Qc23F(III),Gc44F(III),Gc55F(III),Gc66F(III)] = DINSTRAININFNew(MbI,mubI,QbF(III),GbF(III),0,are02F(III),are02F(III),GAMAF01,pF,0,NMAXF);
end
Qd11F = QbF+Qc11F;%The elastic modulus of dry sample P-wave modulus
Qd22F = QbF+Qc22F;%The elastic modulus of dry sample P-wave modulus
Qd33F = QbF+Qc33F;%The elastic modulus of dry sample P-wave modulus
Qd12F = QbF-2*GbF+Qc12F;%The elastic modulus of dry sample P-wave modulus
Qd13F = QbF-2*GbF+Qc13F;%The elastic modulus of dry sample P-wave modulus
Qd23F = QbF-2*GbF+Qc23F;%The elastic modulus of dry sample P-wave modulus
Gd44F = GbF+Gc44F;%The elastic modulus of dry sample Shear modulus
Gd55F = GbF+Gc55F;%The elastic modulus of dry sample Shear modulus
Gd66F = GbF+Gc66F;%The elastic modulus of dry sample Shear modulus
Cos45 = sqrt(1/2);
Sin45 = Cos45;
GG = ((Qd11F-Gd66F).*Sin45.^2-(Qd22F-Gd66F).*Cos45.^2).^2+((Qd12F+Gd66F).^2);
Qd45F = (Qd11F.*Sin45.^2+Qd22F.*Cos45.^2+Gd66F+sqrt(GG))/2;
T = toc;
ed = (Qd22F-Qd11F)./2/Qd22F;
ee = (MF90-MF0)./2./MF90;
gamad = (Gd44F-Gd66F)./2./Gd66F;
gamae = (GhF90-GvF90)./2./GvF90;
dd = 4*(sqrt(Qd45F./Qd11F)-1)-(sqrt(Qd22F./Qd11F)-1);
de = 4*(sqrt(MF45./MF0)-1)-(sqrt(MF90./MF0)-1);
%%
figure(1)
plot(Pred,MeI)
hold on
plot(Pred,QdI)
hold on
plot(Pred,QbI)
legend('Experiment data','Theoretical value (DZ-MT)','Acoustoelasticity')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(2)
plot(Pred,GeI)
hold on
plot(Pred,GdI)
hold on
plot(Pred,GbI)
legend('Experiment data','Theoretical value (DZ-MT)','Acoustoelasticity')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
figure(3)
plot(Pred,MF0)
hold on
plot(Pred,Qd11F)
legend('Experiment data (D11)','Theoretical value (D11)')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(4)
plot(Pred,MF45)
hold on
plot(Pred,Qd45F)
legend('Experiment data (D45)','Theoretical value (D45)')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(5)
plot(Pred,MF90)
hold on
plot(Pred,Qd22F)
legend('Experiment data (D22)','Theoretical value (D22)')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
%%
figure(6)
plot(Pred,(GhF90))
hold on
plot(Pred,Gd44F)
legend('Experiment data (D44)','Theoretical value (D44)')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
figure(7)
plot(Pred,1/1.*(GvF90))
hold on
plot(Pred,Gd66F)
legend('Experiment data (D66)','Theoretical value (D66)')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
figure(8)
plot(Pred,ee)
hold on
plot(Pred,gamae)
hold on
plot(Pred,de)
legend('  ','  ','  ')
xlabel('Differential pressure (MPa)')
ylabel('Anisotropic parameters')