%This code is used to calculated crack distribution
clear
%%
%Basic parameters
%The parameters for quatz
Kb = 9.7;%bulk modulus GPa
mubb = 7.3;%shear modulus GPa
Mbb = Kb+4/3.*mubb;%P-wave modulus GPa
Eb = 9*Kb*mubb/(3*Kb+mubb);%Young's modulus
vb = (3*Kb-2*mubb)/(2*(3*Kb+mubb));%Poisson's ratio
%%
%%
% mb = 0;%3oECs of background unit GPa
% nb = 0;%3oECs of background unit GPa
% lb = 0;%3oECs of background unit GPa
%%
rho = 2140;%density kg/m^3
p011 = 50/1000;%unit GPa
GAMA01 = 0.009;%the initial
NMAX01 = 200;
p022 = 50/1000;%unit GPa
GAMA02 = 0.009;%the initial
NMAX02 = 200;
p033 = 50/1000;%unit GPa
GAMA03 = 0.009;%the initial
NMAX03 = 200;
%%
Pd11 = (0:0.2:12);%Unxial stress
Pd22 = zeros(1,length(Pd11));
Pd33 = zeros(1,length(Pd11));
%%
%The third order elastic constant of air
l1 = -1; %TOE unit GPa
m1 = -1.01e-4; %TOE unit GPa
n1 = 0; %TOE unit GPa
% PHI11ca = 7*Mca-4*muca+6*l1+4*m1;
PHI11ca = 0;
PHI12ca = 0;
%%
%The third-order elastic constant of water
% PHI11cw = -33.52;%unit GPa
PHI11cw = 0;
PHI12cw = 0;
%%
%To deal with the saturated background medium
are011 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pd11/1000;
are022 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pd22/1000;
are033 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pd33/1000;
% NMAX = 200;%The interval of the discrete
% phi = 0.04;%The total porosity of the rock
% PHIC = phic(Mb,mub,are020,are020,GAMA01,p,NMAX);
%%
% A test function
a11 = (0:1e-03:3e-1);
cc11 = zeros(length(Pd11),length(a11));
a22 = (0:1e-03:3e-1);
cc22 = zeros(length(Pd22),length(a22));
a33 = (0:1e-03:3e-1);
cc33 = zeros(length(Pd33),length(a33));
for JJ = 1:length(Pd11)
for II = 1:length(a11)
    if a11(II)<=are011(JJ)
        cc11(JJ,II)=0;
    else
cc11(JJ,II)=(pi.^2.*Kb.*(1-2.*vb).*a11(II).*GAMA01./((1-vb.^2).*p011).*exp(-(3.*pi.*Kb.*(1-2.*vb).*(a11(II)))./(4.*(1-vb.^2).*p011))).*(1-are011(JJ)./a11(II));
cc22(JJ,II)=(pi.^2.*Kb.*(1-2.*vb).*a22(II).*GAMA02./((1-vb.^2).*p022).*exp(-(3.*pi.*Kb.*(1-2.*vb).*(a22(II)))./(4.*(1-vb.^2).*p022))).*(1-are022(JJ)./a22(II));  
cc33(JJ,II)=(pi.^2.*Kb.*(1-2.*vb).*a33(II).*GAMA03./((1-vb.^2).*p033).*exp(-(3.*pi.*Kb.*(1-2.*vb).*(a33(II)))./(4.*(1-vb.^2).*p022))).*(1-are033(JJ)./a33(II));  
    end
end
end
figure(1)
plot(a11-are011(1),cc11(1,:))
hold on
plot(a11-are011(31),cc11(31,:))
hold on
plot(a11-are011(61),cc11(61,:))
legend('Uniaxial pressure0MPa','Uniaxial pressure 6MPa','Uniaxial pressure 12MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')
figure(2)
plot(a22-are022(1),cc22(1,:))
hold on
plot(a22-are022(31),cc22(31,:))
hold on
plot(a22-are022(61),cc22(61,:))
legend('Uniaxial pressure0MPa','Uniaxial pressure 6MPa','Uniaxial pressure 12MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')
figure(3)
plot(a33-are033(1),cc33(1,:))
hold on
plot(a33-are033(31),cc33(31,:))
hold on
plot(a33-are033(61),cc33(61,:))
legend('Uniaxial pressure0MPa','Uniaxial pressure 6MPa','Uniaxial pressure 12MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')