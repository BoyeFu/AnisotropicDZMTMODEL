%This code is used to calculate the stress denpendent velocity for the
%experiment data
clear
%we want to calculate the calculation time
tic
%%
%Basic parameters
%The parameters for the dry rock
Kb = 6.1;%bulk modulus GPa
mub = 6.5;%shear modulus GPa
Mb = Kb+4/3.*mub;%P-wave modulus GPa
Eb = 9*Kb*mub/(3*Kb+mub);%Young's modulus
vb = (3*Kb-2*mub)/(2*(3*Kb+mub));%Poisson's ratio
%%
% mb = -14435;%3oECs of background unit GPa
% nb = -17530;%3oECs of background unit GPa
% lb = -7900;%3oECs of background unit GPa
%%
mb = -4342.32517913922;%3oECs of background unit GPa
nb = -3997.39902661203;%3oECs of background unit GPa
lb = -2358.46966635022;%3oECs of background unit GPa
%%
rho = 2090;%density kg/m^3
p011 = 12/1000;%unit GPa
GAMA01 = 1;%the initial
p022 = 12/1000;%unit GPa
GAMA02 = 1;%the initial
p033 = 12/1000;%unit GPa
GAMA03 = 1;%the initial
%%
%Experiment data
Pd1 = [7.30E-01	2.87E+00	5.94E+00	9.96E+00	1.20E+01	1.40E+01	1.60E+01	1.79E+01	2.00E+01	2.19E+01	2.39E+01	2.59E+01	2.80E+01	2.99E+01	3.19E+01	3.39E+01	3.58E+01	3.78E+01	3.98E+01	4.18E+01];%differential stress in 1 direction, unit MPa
Pd2 = zeros(1,length(Pd1));
Pd3 = zeros(1,length(Pd1));
VP = [2.66E+03	2.75E+03	2.77E+03	2.78E+03	2.79E+03	2.80E+03	2.79E+03	2.78E+03	2.78E+03	2.77E+03	2.76E+03	2.75E+03	2.74E+03	2.71E+03	2.68E+03	2.65E+03	2.60E+03	2.54E+03	2.42E+03	2.17E+03];%P-wave velocity in the direction normal to the stress, m/s
VS1 = [1.82E+03	1.94E+03	2.04E+03	2.11E+03	2.14E+03	2.16E+03	2.18E+03	2.19E+03	2.20E+03	2.22E+03	2.22E+03	2.22E+03	2.22E+03	2.22E+03	2.20E+03	2.19E+03	2.18E+03	2.16E+03	2.13E+03	1.91E+03];%S-wave velocity in the direction normal to the stress, polarization parallel to surface,m/s
VS2 = [1.77E+03	1.85E+03	1.88E+03	1.90E+03	1.91E+03	1.91E+03	1.91E+03	1.91E+03	1.91E+03	1.90E+03	1.90E+03	1.89E+03	1.89E+03	1.87E+03	1.84E+03	1.82E+03	1.79E+03	1.76E+03	1.68E+03	1.47E+03];%S-wave velocity in the direction normal to the stress, polarization normal to surface,m/s
D22e = rho.*VP.^2./1000000000;%D11 value unit GPa
D55e = rho.*VS1.^2./1000000000;%D44e value unit GPa
D44e = rho.*VS2.^2./1000000000;%D55e value unit GPa
%%
%in this research, the compressed force should be negetive value, the
%Stretch force should be positive value
e1 = -Pd1./Eb/1000;%The strain in 1 direction
e2 = -Pd1.*(-vb)./Eb./1000;%The strain in 2 direction
%%
%The third order elastic constant of air
%%
%To deal with the saturated background medium
% are0110 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pd1(end);
% NMAX = 200;%The interval of the discrete
% phi = 0.04;%The total porosity of the rock
% PHIC = phic(Mb,mub,are0110,are0110,GAMA01,p,NMAX);
%%

%%
%%
%we will model the elastic modulus variation of the dry sample
LE = length(e1);%The length of strain, and for every strain, we will have a increase of the elastic moduli
are011 = 4.*(1-vb.^2)./(9.*pi.*Kb.*(1-2.*vb)).*Pd1/1000;
are022 = 4.*(1-vb.^2)./(9.*pi.*Kb.*(1-2.*vb)).*Pd2/1000;
are033 = 4.*(1-vb.^2)./(9.*pi.*Kb.*(1-2.*vb)).*Pd3/1000;
% Qb = zeros(1,LE);
% Gb = zeros(1,LE);
%%
%The background medium elastic moduli
D11b = Mb+(5.*Mb+2.*lb+4.*mb).*e1+2.*(Mb-2.*mub+2.*lb).*e2;
D22b = Mb+(Mb-2.*mub+2.*lb).*e1+(6.*Mb-2.*mub+4.*lb+4.*mb).*e2;
D33b = D22b;
D12b = Mb-2.*mub+(2.*Mb-4.*mub+2.*lb).*e1+(2.*Mb-4.*mub+4.*lb-2.*mb+nb).*e2;
D13b = D12b;
D44b = mub+(Mb-2.*mub+mb-1/2.*nb).*e1+(2.*Mb+2.*mub+2.*mb).*e2;
D55b = mub+(Mb+mb).*e1+(2.*Mb+2.*mb-1/2.*nb).*e2;
D66b = D55b;
D23b = D22b-2.*D44b;
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
D11c1 = zeros(1,LE);
D12c1 = zeros(1,LE);
D13c1 = zeros(1,LE);
D22c1 = zeros(1,LE);
D23c1 = zeros(1,LE);
D33c1 = zeros(1,LE);
D44c1 = zeros(1,LE);
D55c1 = zeros(1,LE);
D66c1 = zeros(1,LE);
%%
D11c2 = zeros(1,LE);
D12c2 = zeros(1,LE);
D13c2 = zeros(1,LE);
D22c2 = zeros(1,LE);
D23c2 = zeros(1,LE);
D33c2 = zeros(1,LE);
D44c2 = zeros(1,LE);
D55c2 = zeros(1,LE);
D66c2 = zeros(1,LE);
%%
D11c3 = zeros(1,LE);
D12c3 = zeros(1,LE);
D13c3 = zeros(1,LE);
D22c3 = zeros(1,LE);
D23c3 = zeros(1,LE);
D33c3 = zeros(1,LE);
D44c3 = zeros(1,LE);
D55c3 = zeros(1,LE);
D66c3 = zeros(1,LE);
%%
NMAX = 200;
parfor II = 1:LE
    Db=[D11b(II) D12b(II) D12b(II) 0 0 0;D12b(II) D22b(II) D23b(II) 0 0 0;D12b(II) D23b(II) D33b(II) 0 0 0;0 0 0 D44b(II) 0 0;0 0 0 0 D55b(II) 0;0 0 0 0 0 D66b(II)];
    [D11c1(II),D12c1(II),D13c1(II),D22c1(II),D23c1(II),D33c1(II),D44c1(II),D55c1(II),D66c1(II)] = DINSTRAININ11(Db,Kb,vb,are011(II),are011(II),are011(II),GAMA01,p011,NMAX);
    [D11c2(II),D12c2(II),D13c2(II),D22c2(II),D23c2(II),D33c2(II),D44c2(II),D55c2(II),D66c2(II)] = DINSTRAININ22(Db,Kb,vb,are022(II),are022(II),are022(II),GAMA02,p022,NMAX);
    [D11c3(II),D12c3(II),D13c3(II),D22c3(II),D23c3(II),D33c3(II),D44c3(II),D55c3(II),D66c3(II)] = DINSTRAININ33(Db,Kb,vb,are033(II),are033(II),are033(II),GAMA03,p033,NMAX);
end
D11d = D11b+D11c1+D11c2+D11c3;
D12d = D12b+D12c1+D12c2+D12c3;
D13d = D13b+D13c1+D13c2+D13c3;
D22d = D22b+D22c1+D22c2+D22c3;
D23d = D23b+D23c1+D23c2+D23c3;
D33d = D33b+D33c1+D33c2+D33c3;
D44d = D44b+D44c1+D44c2+D44c3;
D55d = D55b+D55c1+D55c2+D55c3;
D66d = D66b+D66c1+D66c2+D66c3;
%%
% %We will deal with the saturated sample
% Qbsat = zeros(1,LE);
% Gbsat = zeros(1,LE);
T = toc;
%%
figure(1)
plot(Pd1,D22e)
hold on
plot(Pd1,D22d)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(2)
plot(Pd1,D44e)
hold on
plot(Pd1,D44d)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
figure(3)
plot(Pd1,D55e)
hold on
plot(Pd1,D55d)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
%%

%%
