%This code is used to calculated crack distribution
clear
%%
%Basic parameters
%The parameters for quatz
%The parameters for the dry rock
Kb = 6.1;%bulk modulus GPa
mub = 6.5;%shear modulus GPa
Mb = Kb+4/3.*mub;%P-wave modulus GPa
Eb = 9*Kb*mub/(3*Kb+mub);%Young's modulus
vb = (3*Kb-2*mub)/(2*(3*Kb+mub));%Poisson's ratio
p011 = 9.3/1000;%unit GPa
GAMA01 = 0.753;%the initial
p022 = 9.3/1000;%unit GPa
GAMA02 = 0.753;%the initial
p033 = 9.3/1000;%unit GPa
GAMA03 = 0.753;%the initial
Pd1 = [7.30E-01	2.87E+00	5.94E+00	9.96E+00	1.20E+01	1.40E+01	1.60E+01	1.79E+01	2.00E+01	2.19E+01	2.39E+01	2.59E+01	2.80E+01	2.99E+01	3.19E+01	3.39E+01	3.58E+01	3.78E+01	3.98E+01	4.18E+01];%differential stress in 1 direction, unit MPa
Pd2 = zeros(1,length(Pd1));
Pd3 = zeros(1,length(Pd1));
%%
are011 = 4.*(1-vb.^2)./(9.*pi.*Kb.*(1-2.*vb)).*Pd1./1000;
% NMAX = 200;%The interval of the discrete
% phi = 0.04;%The total porosity of the rock
% PHIC = phic(Mb,mub,are020,are020,GAMA01,p,NMAX);
%%
% A test function a11
a11 = (0:1e-05:5e-03);
cc11 = zeros(length(Pd1),length(a11));
for JJ = 1:length(Pd1)
for II = 1:length(a11)
    if a11(II)<=are011(JJ)
        cc11(JJ,II)=0;
    else
cc11(JJ,II)=(pi.^2.*Kb.*(1-2.*vb).*a11(II).*GAMA01./((1-vb.^2).*p011).*exp(-(3.*pi.*Kb.*(1-2.*vb).*(a11(II)))./(4.*(1-vb.^2).*p011))).*(1-are011(JJ)./a11(II));
    end
end
end
%%
% A test function a22
are022 = 4.*(1-vb.^2)./(9.*pi.*Kb.*(1-2.*vb)).*Pd2./1000;
a22 = (0:1e-05:5e-03);
cc22 = zeros(length(Pd2),length(a22));
for JJ = 1:length(Pd2)
for II = 1:length(a22)
    if a22(II)<=are022(JJ)
        cc22(JJ,II)=0;
    else
cc22(JJ,II)=(pi.^2.*Kb.*(1-2.*vb).*a22(II).*GAMA02./((1-vb.^2).*p022).*exp(-(3.*pi.*Kb.*(1-2.*vb).*(a22(II)))./(4.*(1-vb.^2).*p022))).*(1-are022(JJ)./a22(II));
    end
end
end
%%
% A test function a33
are033 = 4.*(1-vb.^2)./(9.*pi.*Kb.*(1-2.*vb)).*Pd3./1000;
a33 = (0:1e-05:5e-03);
cc33 = zeros(length(Pd3),length(a33));
for JJ = 1:length(Pd3)
for II = 1:length(a33)
    if a33(II)<=are033(JJ)
        cc33(JJ,II)=0;
    else
cc33(JJ,II)=(pi.^2.*Kb.*(1-2.*vb).*a33(II).*GAMA03./((1-vb.^2).*p033).*exp(-(3.*pi.*Kb.*(1-2.*vb).*(a33(II)))./(4.*(1-vb.^2).*p033))).*(1-are033(JJ)./a33(II));
    end
end
end
%%
%Plot
%%
%c11
figure(1)
plot(a11-are011(1),cc11(1,:))
hold on
plot(a11-are011(3),cc11(3,:))
hold on
plot(a11-are011(7),cc11(7,:))
legend('Differential pressure 3.9MPa','Differential pressure 20MPa','Differential pressure 51MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')
%%
%c22
figure(2)
plot(a22-are022(1),cc22(1,:))
hold on
plot(a22-are022(3),cc22(3,:))
hold on
plot(a22-are022(7),cc22(7,:))
legend('Differential pressure 3.9MPa','Differential pressure 20MPa','Differential pressure 51MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')
%%
%c33
figure(3)
plot(a33-are033(1),cc33(1,:))
hold on
plot(a33-are033(3),cc33(3,:))
hold on
plot(a33-are033(7),cc33(7,:))
legend('Differential pressure 3.9MPa','Differential pressure 20MPa','Differential pressure 51MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')