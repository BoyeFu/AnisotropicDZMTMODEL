%This code is used to calculated crack distribution
clear
%%
%Basic parameters
%The parameters for quatz
Kgr = 37; %Bulk modulus of quatz
mugr = 44; %Shear modulus of quatz
Mca = 1.01e-04;%the P-wave modulus of air unit GPa
muca = 0;%Shear modulus of aire
Mcw = 2.25;%The P-wave modulus (bulk modulus) of water
mucw = 0;%Shear moudlus of water
p = 9/1000;%unit GPa
GAMA01 = 0.226;%the initial
%%
Qe = [68.2060261	76.06422991	80.11812245	82.29214812	83.95543008	84.2983426	85.1009935	85.36280653	86.12845332	86.60218738	87.41570662	87.04567013	87.35278678	87.61744119	87.88279495	88.40420812	87.86156384	88.42550468];%P-wave modulus in experiment
Ge = [32.36420043	35.54222229	37.19481967	38.14358006	38.57982943	39.03549843	39.17034494	39.80075747	39.62867454	39.93591024	39.84927331	40.1401805	40.07048438	40.06947473	40.36118311	40.2050826	40.37658683	40.35834591];% S-wave modulus in experiment
KKE = Qe-4./3*Ge;
Qew = [80.92979739	83.49201885	85.54556605	86.22338567	86.60652653	87.45861972	87.6740257	87.93250082	88.02025186	88.15090399	88.19618715	88.58368154	88.84349311	88.88865068	89.10580948	89.15133721	89.06787859	89.45728109];%P-wave modulus saturated with water
Gew = [35.2706331	37.25269447	38.34890811	38.91159889	39.08285335	39.27160712	39.58167839	39.65088366	39.85825323	39.82375552	40.03177948	39.94496924	40.18815307	40.48422071	40.46683504	40.39692102	40.34483148	40.46683504];%S-wave modulus saturated with water
Ke = Qe-4/3*Ge;
eexp = [0.000144449	0.000288897	0.000433346	0.000577795	0.000722243	0.000866692	0.001011141	0.001155589	0.001300038	0.001444487	0.001588935	0.001733384	0.001877832	0.002022281	0.00216673	0.002311178	0.002455627	0.002600076]./3;
e=(0.0001:0.0001:0.0026)./3;%The strain or theoritical value
K0 = Ke(end);
Pee = 3.*eexp.*K0; %Confining pressure,unit GPa
Pet = 3.*e.*K0;%The theoretical confining pressure
%Caculate the third-order elastic constant of the experiment
%The third-order elstic constants for P-wave modulus for background medium
[TOEP,QQ0] = polyfit(eexp(15:end),Qe(15:end),1);
PHI01 = -TOEP(1);%This is the third-order elastic constant for P-wave modulus
Mb = TOEP(2);%The P-wave modulus when the pressure is zero
%The third-order elstic constants for shear modulus for background medium
[TOES,GG0] = polyfit(eexp(15:end),Ge(15:end),1);
PHI02 = -TOES(1);%This is the third-order elastic constant for shear modulus
mub = TOES(2);%The background shear modulus when the pressure is zero
Kb = Mb-4./3.*mub;%The bulk moudulus of background medium when the pressure is at zero
vb=(Mb-2*mub)/(2*(Mb-mub)); %Poisson ratio
%%
%The third order elastic constant of air
l1 = -1; %TOE unit GPa
m1 = -1.01e-4; %TOE unit GPa
n1 = 0; %TOE unit GPa
% PHI11ca = 7*Mca-4*muca+6*l1+4*m1;
PHI11ca = 0;
PHI12ca = 0;
%%
%The third-order elastic constant of water
% PHI11cw = -33.52;%unit GPa
PHI11cw = 0;
PHI12cw = 0;
%%
%To deal with the saturated background medium
arf = 1-Kb./Kgr;%Biot-Willis coefficient
are020 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pet;
% NMAX = 200;%The interval of the discrete
% phi = 0.04;%The total porosity of the rock
% PHIC = phic(Mb,mub,are020,are020,GAMA01,p,NMAX);
%%
% A test function
a = (0:1e-05:5e-03);
cc = zeros(length(Pet),length(a));
for JJ = 1:length(Pet)
for II = 1:length(a)
    if a(II)<=are020(JJ)
        cc(JJ,II)=0;
    else
cc(JJ,II)=(pi.^2.*Kb.*(1-2.*vb).*a(II).*GAMA01./((1-vb.^2).*p).*exp(-(3.*pi.*Kb.*(1-2.*vb).*(a(II)))./(4.*(1-vb.^2).*p))).*(1-are020(JJ)./a(II));
    end
end
end
figure(1)
plot(a-are020(1),cc(1,:))
hold on
plot(a-are020(6),cc(6,:))
hold on
plot(a-are020(15),cc(15,:))
legend('Differential pressure 3.5MPa','Differential pressure 21MPa','Differential pressure 52MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')