%This code is used to model the stress-dependent elastic moduli
%%
clear
%%
%The data is still used in the Geophysics
%%
%The parameters of Granite
%Second-order elastic modulus-Granite
K0 = 13.8; %bulk modulus
mu0 = 18.2; %unit GPa
M0 = K0+4/3.*mu0; %unit GPa
v0=(M0-2*mu0)/(2*(M0-mu0)); %Poisson ratio
%Third-order elastic constant-Granite
l0 = -3371; %TOE unit GPa
m0 = -6742; %TOE unit GPa
n0 = -6600; %TOE unit GPa
%The parameters of Air
%Second-order elastic modulus-Air
K1 = 1.01e-04; %Bulk modulus unit GPa
mu1 = 0; %unit GPa
M1 = K1+4/3.*mu1; %unit GPa
%Third-order elastic constant-Air
l1 = -1; %TOE unit GPa
m1 = -1.01e-4; %TOE unit GPa
n1 = 0; %TOE unit GPa
p = 1;%unit GPa
GAMA01 = 0.1;
NMAX = 200;%The integration discrete
%System TOE
PHI01 = 7*M0-4*mu0+6*l0+4*m0;
PHI11 = 7*M1-4*mu1+6*l1+4*m1;
PHI02 = 3*M0+3*m0-1/2*n0;
PHI12 = 3*M1+3*m1-1/2*n1;
%%
e=(0.0001:0.0001:0.001);
P = 3.*e.*K0;
LE = length(e);%The length of strain, and for every strain, we will have a increase of the elastic moduli
are02 = 4.*(1-v0.^2)./(3.*pi.*K0.*(1-2.*v0)).*P;
Q0 = zeros(1,LE);
G0 = zeros(1,LE);
for i = 1:LE
OMIGB01 = OMIGbINFI(M0,mu0,M1,mu1,are02(i),are02(i),GAMA01,p,NMAX);
OMIGBM = ROTAIN(OMIGB01,NMAX);
OMIGB = OMIGBM(1,1)+OMIGBM(1,2)+OMIGBM(1,3);
%%
%The background medium elastic moduli
Q0(i) = M0+PHI01.*OMIGB.*e(i);
G0(i) = mu0+PHI02.*OMIGB.*e(i);
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
end
Qcin = zeros(1,LE);
Gcin = zeros(1,LE);
for i = 1:LE
    [Qcin(i),Gcin(i)] = DINSTRAININ(Q0(i),G0(i),M0,mu0,M1,mu1,PHI11,PHI12,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
end
Q = Q0+Qcin;
G = G0+Gcin;
figure(1)
plot(e.*100,Q)
xlabel('Strain (%)')
ylabel('P-wave modulus (GPa)')
figure(2)
plot(e.*100,G)
xlabel('Strain (%)')
ylabel('Shear modulus (GPa)')
%%
%Analyze the linear part
QL = zeros(1,LE);
GL = zeros(1,LE);
for i = 1:LE
    [QL(i),GL(i)] = DLINEAR(Q0(i),G0(i),M0,mu0,M1,mu1,PHI11,PHI12,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
end
figure(3)
plot(e.*100,QL)
xlabel('Strain (%)')
ylabel('P-wave modulus (GPa)')
figure(4)
plot(e.*100,GL)
xlabel('Strain (%)')
ylabel('Shear modulus (GPa)')