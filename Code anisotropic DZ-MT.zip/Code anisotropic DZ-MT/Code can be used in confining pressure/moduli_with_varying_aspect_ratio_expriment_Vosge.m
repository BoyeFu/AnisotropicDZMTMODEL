%This code is used to calculate the stress denpendent velocity for the
%experiment data
clear
tic
%Basic parameters
%The parameters for quatz
Kq = 37;%Quartz 0.5
muq = 44;%Quartz
KF = 37.5;%Feldspars 0.3
muF = 15.0;%Feldspars
KB = 41.1;%Biotite 0.2
muB = 12.4;%Biotite
Kgr = (0.5./(Kq+4./3.*muq)+0.3./(KF+4./3.*muq)+0.2./(KB+4./3.*muq)).^(-1)-4./3.*muq; %Bulk modulus of quatz
KESI = 44./6.*((9.*37+8.*44)./(37+2.*44));
mugr = (0.5./(muq+KESI)+0.3./(muF+KESI)+0.2./(muB+KESI)).^(-1)-KESI; %Shear modulus of quatz
%%
Qe = [10.91103197	15.95613217	19.04699084	20.88560232	22.13820131	23.08611986	24.08542379	24.75282734	25.00943555	25.29966637	25.85262197	26.01632654	26.11485437	26.44457752	26.70978761	26.87617969	26.84288888	27.00969438	27.00969438	27.14353989	27.31127549	27.44586524	27.44586524];%P-wave modulus in experiment
Ge = [4.686507292	6.596323906	7.79516475	8.420020676	9.008760876	9.3344675	9.591601322	9.764499328	9.951624667	10.12772331	10.21590546	10.29147441	10.36741175	10.46936683	10.54595646	10.55784105	10.63466195	10.64650527	10.73682139	10.73563174	10.73444217	10.81199358	10.81070795];% S-wave modulus in experiment
Qew = [13.96799727	21.74296094	27.92626674	28.72608196	29.64853783	30.28428489	30.77485932	31.15502101	31.49904528	31.61419541	31.72955564	31.92217781	32.19292914	32.23165312	32.46482383	32.46482383	32.65966168	32.65966168	32.62068136	32.65966168	32.65966168	32.58172432	32.58172432];%P-wave modulus saturated with water
Gew = [4.347369032	6.901884634	9.212696349	9.498321944	10.0829368	10.25833335	10.51781716	10.62748829	10.82158656	10.90469347	10.90371389	11.01537364	11.11345599	11.11246708	11.18259055	11.19588732	11.20909268	11.19380298	11.23562619	11.20611335	11.20521963	11.21843049	11.23174855];
Ke = Qe-4/3*Ge;
eexp = [0	0.000383683	0.000767366	0.001151049	0.001534732	0.001918415	0.002302099	0.002685782	0.003069465	0.003453148	0.003836831	0.004220514	0.004604197	0.00498788	0.005371563	0.005755246	0.00613893	0.006522613	0.006906296	0.007289979	0.007673662	0.008057345	0.008441028]./3;
e=(0.0003:0.00001:0.008)./3;%The strain or theoritical value
K0 = Ke(end);
Pee = 3.*eexp.*K0; %Confining pressure,unit GPa
Pet = 3.*e.*K0;%The theoretical confining pressure
p = 10;%unit GPa
%Caculate the third-order elastic constant of the experiment
%The third-order elstic constants for P-wave modulus for background medium
[TOEP,QQ0] = polyfit(eexp(10:18),Qe(10:18),1);
PHI01 = -TOEP(1);%This is the third-order elastic constant for P-wave modulus
Mb = TOEP(2);%The P-wave modulus when the pressure is zero
%The third-order elstic constants for shear modulus for background medium
[TOES,GG0] = polyfit(eexp(10:18),Ge(10:18),1);
PHI02 = -TOES(1);%This is the third-order elastic constant for shear modulus
mub = TOES(2);%The background shear modulus when the pressure is zero
Kb = Mb-4./3.*mub;%The bulk moudulus of background medium when the pressure is at zero
vb=(Mb-2*mub)/(2*(Mb-mub)); %Poisson ratio
%%
%The third order elastic constant of air
l1 = -1; %TOE unit GPa
m1 = -1.01e-4; %TOE unit GPa
n1 = 0; %TOE unit GPa
PHI11ca = 7*Mca-4*muca+6*l1+4*m1;
PHI12ca = 0;
%%
%The third-order elastic constant of water
PHI11cw = -33.52;%unit GPa
PHI12cw = 0;
%%
%To deal with the saturated background medium
arf = 1-Kb./Kgr;%Biot-Willis coefficient
are020 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*0;
GAMA01 = 0.01;
NMAX = 200;%The interval of the discrete
phi = 0.04;%The total porosity of the rock
phic = phic(Mb,mub,are020,are020,GAMA01,p,NMAX);
phib = phi-phic;%The stiff porosity
MM = ((arf-phib)./Kgr+phib./Mcw).^(-1);
Mbsat = Mb+arf.^2.*MM;%The saturated background bulk modulus
mubsat = mub;%The saturated background shear modulus
%%
%we will model the elastic modulus variation of the dry sample
LE = length(e);%The length of strain, and for every strain, we will have a increase of the elastic moduli
are02 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pet;
Qb = zeros(1,LE);
Gb = zeros(1,LE);
for i = 1:LE
OMIGB01b = OMIGbINFI(Mb,mub,Mca,muca,are02(i),are02(i),GAMA01,p,NMAX);
OMIGBMb = ROTAIN(OMIGB01b,NMAX);
OMIGBb = OMIGBMb(1,1)+OMIGBMb(1,2)+OMIGBMb(1,3);
%%
%The background medium elastic moduli
Qb(i) = Mb+PHI01.*OMIGBb.*e(i);
Gb(i) = mub+PHI02.*OMIGBb.*e(i);
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
end
Qcain = zeros(1,LE);
Gcain = zeros(1,LE);
for i = 1:LE
    [Qcain(i),Gcain(i)] = DINSTRAININ(Qb(i),Gb(i),Mb,mub,Mca,muca,PHI11ca,PHI12ca,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
end
Qd = Qb+Qcain;%The elastic modulus of dry sample P-wave modulus
Gd = Gb+Gcain;%The elastic modulus of dry sample Shear modulus
%%
%We will deal with the saturated sample
Qbsat = zeros(1,LE);
Gbsat = zeros(1,LE);
for i = 1:LE
OMIGB01bsat = OMIGbINFI(Mbsat,mubsat,Mcw,mucw,are02(i),are02(i),GAMA01,p,NMAX);
OMIGBMbsat = ROTAIN(OMIGB01bsat,NMAX);
OMIGBbsat = OMIGBMbsat(1,1)+OMIGBMbsat(1,2)+OMIGBMbsat(1,3);
%%
%The background medium elastic moduli
Qbsat(i) = Mb+PHI01.*OMIGBbsat.*e(i);
Gbsat(i) = mub+PHI02.*OMIGBbsat.*e(i);
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
end
Qcwin = zeros(1,LE);
Gcwin = zeros(1,LE);
for i = 1:LE
    [Qcwin(i),Gcwin(i)] = DINSTRAININ(Qb(i),Gb(i),Mb,mub,Mcw,mucw,PHI11cw,PHI12cw,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
end
Qsat = Qbsat+Qcwin;%The elastic modulus of saturated sample P-wave modulus
Gsat = Gbsat+Gcwin;%The elastic modulus of saturated sample Shear modulus
T = toc;
%%
figure(1)
plot(Pee.*1000,Qe)
hold on
plot(Pet.*1000,Qd)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(2)
plot(Pee.*1000,Ge)
hold on
plot(Pet.*1000,Gd)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
%%
figure(3)
plot(Pee.*1000,Qew)
hold on
plot(Pet.*1000,Qsat)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(4)
plot(Pee.*1000,Gew)
hold on
plot(Pet.*1000,Gsat)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
%Analyze the linear part
%%
%Dry sample
QLcd = zeros(1,LE);
GLcd = zeros(1,LE);
phib = zeros(1,LE);
for i = 1:LE
    [QLcd(i),GLcd(i),phib(i)] = DLINEAR(Qb(i),Gb(i),Mb,mub,Mca,muca,PHI11ca,PHI12ca,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
end
QLd = phib.*Qb+QLcd;
GLd = phib.*Gb+GLcd;
%%
figure(5)
plot(Pee.*1000,Qe)
hold on
plot(Pet.*1000,QLd)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(6)
plot(Pee.*1000,Ge)
hold on
plot(Pet.*1000,GLd)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
%Saturated condition
QLcsat = zeros(1,LE);
GLcsat = zeros(1,LE);
phibsat = zeros(1,LE);
for i = 1:LE
    [QLcsat(i),GLcsat(i),phibsat(i)] = DLINEAR(Qb(i),Gb(i),Mb,mub,Mcw,mucw,PHI11cw,PHI12cw,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
end
QLsat = phib.*Qbsat+QLcd;
GLsat = phib.*Gbsat+GLcd;
%%
figure(7)
plot(Pee.*1000,Qew)
hold on
plot(Pet.*1000,QLsat)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(8)
plot(Pee.*1000,Gew)
hold on
plot(Pet.*1000,GLsat)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')