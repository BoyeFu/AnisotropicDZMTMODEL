%This is the function to calculte integratation in OMIGb
%%
%In this function we nedd the parmters of the background medium (Mb,mub)
%the paramters of fracture (Mc,muc)
%The paramters of the fracture aspect ratio initial sapect ratio(are01), and
%critical aspect ratio (are02) and the initial fracture distribution GAMA01
%the critical pressure p
function OMIGbIN=OMIGbIN(Mb,mub,Mc,muc,arf01,arf02,GAMA01,p)
%are = are01-are02; %The aspect ration in the rock
Kb = Mb-4./3.*mub;%bulk modulus
vb=(Mb-2*mub)/(2*(Mb-mub));%Poisson's ratio
%%
ca = pi.^2.*Kb.*(1-2.*vb).*arf01.*GAMA01./((1-vb.^2).*p).*exp(-(3.*pi.*Kb.*(1-2.*vb).*arf01)./(4.*(1-vb.^2).*p));
%%
PP = MMPCC(Mb,mub,Mc,muc,arf01,arf02);
OMIGbIN01 = PP;
%%
if arf01<arf02
    OMIGbIN=0;
else
OMIGbIN = ca.*(1-arf02./arf01).*OMIGbIN01;
%%
end
end