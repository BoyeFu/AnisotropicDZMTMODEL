%This code is used to calculate the stress denpendent velocity for the
%experiment data
clear
%we want to calculate the calculation time
tic
%%
%Basic parameters
%The parameters for quatz
Kgr = 37; %Bulk modulus of quatz
mugr = 44; %Shear modulus of quatz
Mca = 1.01e-04;%the P-wave modulus of air unit GPa
muca = 0;%Shear modulus of aire
Mcw = 2.25;%The P-wave modulus (bulk modulus) of water
mucw = 0;%Shear moudlus of water
p = 8/1000;%unit MPa
GAMAI01 = 0.25;%the initial
NMAXI = 200;
pF = 1000/1000;%unit MPa
GAMAF01 = 0.020;%the initial
NMAXF = 200;
%%
%Load experiment data
%%
%P-wave modulus
MI0 = [25.64755065	28.80605385	31.26794625	33.45309385	35.13073465	36.67176	38.064865	39.17766625	40.07945065	40.8873376];%P-wave modulus direction 0
MI45 = [26.629585	29.75738265	32.03725185	33.96346	35.7314976	36.92851585	38.3062906	39.4430346	40.2651706	41.1793146];%P-wave modulus direction 45
MI90 = [27.08514385	30.2030464	32.59247985	34.6882986	36.25889265	37.68416865	38.9538234	39.9352986	40.70018665	41.36756265];%P-wave modulus direction 90
MeI = 1/3.*(MI0+MI45+MI90);%The effective P-wave modulus
%%
%Shear modulus
GhI0 = [7.9679034	9.1482346	10.18024	10.9419136	11.7087706	12.2724256	12.86100385	13.3203946	13.7033514	14.03069265];%Shear h modulus direction 0
GhI45 = [8.2647034	9.4460416	10.4731816	11.2237146	11.9776714	12.5246314	13.09558185	13.53514	13.896865	14.20194625];%Shear h modulus direction 45
GhI90 = [8.6624896	9.84032185	10.8559264	11.63091625	12.3180904	12.83766265	13.37987385	13.78784665	14.1161896	14.386585];%Shear h modulus direction 90
GvI0 = [8.2459944	9.37612665	10.3680826	11.1149056	11.87647585	12.44410585	12.90774985	13.3679674	13.71540625	14.0428906];%Shear V modulus direction 0
GvI45 = [8.06931625	9.266785	10.25308585	11.03905465	11.798065	12.37529065	12.942865	13.33227985	13.7274664	13.9697824];%Shear V modulus direction 45
GvI90 = [8.21797065	9.4060584	10.39955665	11.1583656	11.92139865	12.53615625	12.95458065	13.3441704	13.655185	14.0185];%Gv modulus direction 90
GeI = 1/6.*(GhI0+GhI45+GhI90+GvI0+GvI45+GvI90);%The effective P-wave modulus
%%
Pred = [5	10	15	20	25	30	35	40	45	50];%differential pressure
%%
%Do linear fitting P-wave
CoePI0 = polyfit(Pred(6:end),MI0(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 0
CoePI45 = polyfit(Pred(6:end),MI45(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 45
CoePI90 = polyfit(Pred(6:end),MI90(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 90
%%
%Do linear fitting Sh-wave
CoeShI0 = polyfit(Pred(6:end),GhI0(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 0
CoeShI45 = polyfit(Pred(6:end),GhI45(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 45
CoeShI90 = polyfit(Pred(6:end),GhI90(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 90
%%
%Do linear fitting SV-wave
CoeSvI0 = polyfit(Pred(6:end),GvI0(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 0
CoeSvI45 = polyfit(Pred(6:end),GvI45(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 45
CoeSvI90 = polyfit(Pred(6:end),GvI90(6:end),1);%The linear fit coefficent of the  P-wave modulus in direction 90
%%
% CoePI = 1/3.*(CoePI0+CoePI45+CoePI90);
% CoeSI = 1/6.*(CoeShI0+CoeShI45+CoeShI90+CoeSvI0+CoeSvI45+CoeSvI90);
CoePI = polyfit(Pred(6:end),MeI(6:end),1);
CoeSI = polyfit(Pred(6:end),GeI(6:end),1);
MbI = CoePI(2);%The P-wave modulus when the pressure is zero
mubI = CoeSI(2);%The background shear modulus when the pressure is zero
KbI = MbI-4./3.*mubI;%The bulk moudulus of background medium when the pressure is at zero
vbI=(MbI-2*mubI)/(2*(MbI-mubI)); %Poisson ratio
%%

%%
%To deal with the saturated background medium
LE = length(Pred);%The length of strain, and for every strain, we will have a increase of the elastic moduli
are02I = 4.*(1-vbI.^2)./(3.*pi.*KbI.*(1-2.*vbI)).*Pred/1000;
% Qb = zeros(1,LE);
% Gb = zeros(1,LE);
%%
%The background medium elastic moduli
QbI = polyval(CoePI,Pred);
GbI = polyval(CoeSI,Pred);
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
QcainI = zeros(1,LE);
GcainI = zeros(1,LE);
QcrI = zeros(1,LE);
GcrI = zeros(1,LE);
phiccI = zeros(1,LE);
phibbI = zeros(1,LE);
parfor II = 1:LE
%     [Qcain(II),Gcain(II),Qcr(II),Gcr(II)] = DINSTRAININ(Qb(II),Gb(II),Mb,mub,Mca,muca,PHI11ca,PHI12ca,are02(II),are02(II),are02(II),GAMA01,p,e(II),NMAX);
    [QcainI(II),GcainI(II),QcrI(II),GcrI(II),phibbI(II),phiccI(II)] = DINSTRAININ(QbI(II),GbI(II),MbI,mubI,Mca,muca,0,0,are02I(II),are02I(II),are02I(II),GAMAI01,p,0,NMAXI);
end
QdI = QbI+QcainI;%The elastic modulus of dry sample P-wave modulus
GdI = GbI+GcainI;%The elastic modulus of dry sample Shear modulus
%%
% A test function
a = (0:1e-04:5e-02);
cc = zeros(length(Pred),length(a));
for JJ = 1:length(Pred)
for II = 1:length(a)
    if a(II)<=are02I(JJ)
        cc(JJ,II)=0;
    else
cc(JJ,II)=(pi.^2.*KbI.*(1-2.*vbI).*a(II).*GAMAI01./((1-vbI.^2).*p).*exp(-(3.*pi.*KbI.*(1-2.*vbI).*(a(II)))./(4.*(1-vbI.^2).*p))).*(1-are02I(JJ)./a(II));
    end
end
end
figure(1)
plot(a-are02I(1),cc(1,:))
hold on
plot(a-are02I(5),cc(5,:))
hold on
plot(a-are02I(10),cc(10,:))
legend('Differential pressure 5MPa','Differential pressure 25MPa','Differential pressure 50MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')
KbF = QdI-4./3.*GdI;%The bulk moudulus of background medium when the pressure is at zero
vbF=(GdI-2.*GdI)./(2.*(QdI-GdI)); %Poisson ratio
are02F = 4.*(1-vbF.^2)./(3.*pi.*KbF.*(1-2.*vbF)).*Pred/1000;
a11 = (0:1e-04:5e-02);
cc11 = zeros(length(Pred),length(a11));
PHIF = zeros(1,length(Pred));
for JJ = 1:length(Pred)
for II = 1:length(a11)
    if a11(II)<=are02F(JJ)
        cc11(JJ,II)=0;
    else
cc11(JJ,II)=(pi.^2.*KbF(JJ).*(1-2.*vbF(JJ)).*a11(II).*GAMAF01./((1-vbF(JJ).^2).*pF).*exp(-(3.*pi.*KbF(JJ).*(1-2.*vbF(JJ)).*(a11(II)))./(4.*(1-vbF(JJ).^2).*pF))).*(1-are02F(JJ)./a11(II));
    end
end
PHIF(JJ) = phicF(QdI(JJ),GdI(JJ),are02F(JJ),are02F(JJ),GAMAF01,pF,NMAXF);
end
figure(2)
plot(a11-are02F(1),cc11(1,:))
hold on
plot(a11-are02F(5),cc11(5,:))
hold on
plot(a11-are02F(10),cc11(10,:))
legend('Differential pressure 5MPa','Differential pressure 25MPa','Differential pressure 50MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')
% PHIF = sum(cc11,2);
%%
%Total
ccT = cc+cc11;
figure(3)
plot(a11-are02F(1),ccT(1,:))
hold on
plot(a11-are02F(5),ccT(5,:))
hold on
plot(a11-are02F(10),ccT(10,:))
legend('Differential pressure 5MPa','Differential pressure 25MPa','Differential pressure 50MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')