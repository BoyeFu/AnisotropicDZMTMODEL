%This code is used to calculated crack distribution
clear
%%
%Basic parameters
%The parameters for quatz
Kq = 37;%Quartz 0.5
muq = 44;%Quartz
KF = 75.6;%Feldspars 0.3
muF = 25.6;%Feldspars
KB = 61.5;%Biotite 0.2
muB = 41.1;%Biotite
Kgr = (0.5./(Kq+4./3.*muq)+0.3./(KF+4./3.*muq)+0.2./(KB+4./3.*muq)).^(-1)-4./3.*muq; %Bulk modulus of quatz
KESI = muq./6.*((9.*KF+8.*muq)./(KF+2.*muq));
mugr = (0.5./(muq+KESI)+0.3./(muF+KESI)+0.2./(muB+KESI)).^(-1)-KESI; %Shear modulus of quatz
Mca = 1.01e-04;%the P-wave modulus of air unit GPa
muca = 0;%Shear modulus of aire
Mcw = 2.25;%The P-wave modulus (bulk modulus) of water
mucw = 0;%Shear moudlus of water
p = 9.3/1000;%unit GPa
GAMA01 = 0.753;%the initial
%%
Qe = [10.91103197	15.95613217	19.04699084	20.88560232	22.13820131	23.08611986	24.08542379	24.75282734	25.00943555	25.29966637	25.85262197	26.01632654	26.11485437	26.44457752	26.70978761	26.87617969	26.84288888	27.00969438	27.00969438	27.14353989	27.31127549	27.44586524	27.44586524];%P-wave modulus in experiment
Ge = [4.686507292	6.596323906	7.79516475	8.420020676	9.008760876	9.3344675	9.591601322	9.764499328	9.951624667	10.12772331	10.21590546	10.29147441	10.36741175	10.46936683	10.54595646	10.55784105	10.63466195	10.64650527	10.73682139	10.73563174	10.73444217	10.81199358	10.81070795];% S-wave modulus in experiment
Qew = [13.96799727	21.74296094	27.92626674	28.72608196	29.64853783	30.28428489	30.77485932	31.15502101	31.49904528	31.61419541	31.72955564	31.92217781	32.19292914	32.23165312	32.46482383	32.46482383	32.65966168	32.65966168	32.62068136	32.65966168	32.65966168	32.58172432	32.58172432];%P-wave modulus saturated with water
Gew = [4.347369032	6.901884634	9.212696349	9.498321944	10.0829368	10.25833335	10.51781716	10.62748829	10.82158656	10.90469347	10.90371389	11.01537364	11.11345599	11.11246708	11.18259055	11.19588732	11.20909268	11.19380298	11.23562619	11.20611335	11.20521963	11.21843049	11.23174855];
Ke = Qe-4/3*Ge;
eexp = [0	0.000383683	0.000767366	0.001151049	0.001534732	0.001918415	0.002302099	0.002685782	0.003069465	0.003453148	0.003836831	0.004220514	0.004604197	0.00498788	0.005371563	0.005755246	0.00613893	0.006522613	0.006906296	0.007289979	0.007673662	0.008057345	0.008441028]./3;
e=(0.0003:0.0006:0.008)./3;%The strain or theoritical value
K0 = Ke(end);
Pee = 3.*eexp.*K0; %Confining pressure,unit GPa
Pet = 3.*e.*K0;%The theoretical confining pressure
%Caculate the third-order elastic constant of the experiment
%The third-order elstic constants for P-wave modulus for background medium
[TOEP,QQ0] = polyfit(eexp(15:end),Qe(15:end),1);
PHI01 = -TOEP(1);%This is the third-order elastic constant for P-wave modulus
Mb = TOEP(2);%The P-wave modulus when the pressure is zero
%The third-order elstic constants for shear modulus for background medium
[TOES,GG0] = polyfit(eexp(15:end),Ge(15:end),1);
PHI02 = -TOES(1);%This is the third-order elastic constant for shear modulus
mub = TOES(2);%The background shear modulus when the pressure is zero
Kb = Mb-4./3.*mub;%The bulk moudulus of background medium when the pressure is at zero
vb=(Mb-2*mub)/(2*(Mb-mub)); %Poisson ratio
%%
%The third order elastic constant of air
l1 = -1; %TOE unit GPa
m1 = -1.01e-4; %TOE unit GPa
n1 = 0; %TOE unit GPa
% PHI11ca = 7*Mca-4*muca+6*l1+4*m1;
PHI11ca = 0;
PHI12ca = 0;
%%
%The third-order elastic constant of water
% PHI11cw = -33.52;%unit GPa
PHI11cw = 0;
PHI12cw = 0;
%%
%To deal with the saturated background medium
arf = 1-Kb./Kgr;%Biot-Willis coefficient
are020 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pet;
% NMAX = 200;%The interval of the discrete
% phi = 0.04;%The total porosity of the rock
% PHIC = phic(Mb,mub,are020,are020,GAMA01,p,NMAX);
%%
% A test function
a = (0:1e-05:5e-03);
cc = zeros(length(Pet),length(a));
for JJ = 1:length(Pet)
for II = 1:length(a)
    if a(II)<=are020(JJ)
        cc(JJ,II)=0;
    else
cc(JJ,II)=(pi.^2.*Kb.*(1-2.*vb).*a(II).*GAMA01./((1-vb.^2).*p).*exp(-(3.*pi.*Kb.*(1-2.*vb).*(a(II)))./(4.*(1-vb.^2).*p))).*(1-are020(JJ)./a(II));
    end
end
end
figure(1)
plot(a-are020(1),cc(1,:))
hold on
plot(a-are020(3),cc(3,:))
hold on
plot(a-are020(7),cc(7,:))
legend('Differential pressure 3.9MPa','Differential pressure 20MPa','Differential pressure 51MPa')
xlabel('Crack aspect ratio')
ylabel('Crack porosity')