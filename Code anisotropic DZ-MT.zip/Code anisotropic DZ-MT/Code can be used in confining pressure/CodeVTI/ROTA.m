%This code will be used to model the rotation of the fracture
%The variation of the function is a matrix
%MAX is the maxtrix
%cita is angle in the xoy [0,pi],phi [0,2*pi]
function ROTA = ROTA(MAX,cita,phi)
H = [cos(cita) sin(cita).*cos(phi) sin(cita).*sin(phi);-sin(cita) cos(cita).*cos(phi) cos(cita).*sin(phi);0 -sin(phi) cos(phi)];
T1 = [H(1,1).^2 H(2,1).^2 H(3,1).^2;H(1,2).^2 H(2,2).^2 H(3,2).^2;H(1,3).^2 H(2,3).^2 H(3,3).^2];
T2 = [H(2,1).*H(3,1) H(3,1).*H(1,1) H(1,1).*H(2,1);H(2,2).*H(3,2) H(3,2).*H(1,2) H(1,2).*H(2,2);H(2,3).*H(3,3) H(3,3).*H(1,3) H(1,3).*H(2,3)];
T3 = [H(1,2).*H(1,3) H(2,2).*H(2,3) H(3,2).*H(3,3);H(1,3).*H(1,1) H(2,3).*H(2,1) H(3,3).*H(3,1);H(1,2).*H(1,1) H(2,1).*H(2,2) H(3,1).*H(3,2)];
T4 = [H(2,2).*H(3,3)+H(2,3).*H(3,2) H(3,2).*H(1,3)+H(3,3).*H(1,2) H(1,2).*H(2,3)+H(1,3).*H(2,2);H(2,3).*H(3,1)+H(2,1).*H(3,3) H(3,3).*H(1,1)+H(3,1).*H(1,3) H(1,3).*H(2,1)+H(1,1).*H(2,3);H(2,1).*H(3,2)+H(2,2).*H(3,1) H(3,1).*H(1,2)+H(3,2).*H(1,1) H(1,1).*H(2,2)+H(1,2).*H(2,1)];
T = [T1 2.*T2;T3 T4];
ROTA = T*MAX/T;
end
