%The sries of function is used to calculate the P matrix when the
%background meidum is a VTI medium (C11=C22 C23=C13 C44=C55)
%The function is made from Effective elastic modulus of a transverse isotropy solid with aligned inhomogeneity Xu Song Tang Xiao-Ming Su Yuan-Da Citation: Acta Physica Sinica, 64, 206201 (2015) DOI: 10.7498/aps.64.206201
%The code is used to calculate P matrx,the result is a 6*6 matrix
%a1 = a2 = r, a3/a = gama,aspect ratio
function P = PMATRIX1(C,r,gama,NMAX)
P = zeros(6,6);
%In this fiunction x=sin(cita)cos(phi),y = sin(cita)sin(phi), z =
%cos(cita),0<cita<pi,0<phi<2*pi, we will do intergatation, we will discete
%the integration domain first
%%
%The integration of cita
x2=pi;%the high limit of the integration
x1=0;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
m=(NMAX+1)/2;%%？
xm=(x2+x1)/2;%midpoint 
xl=(x2-x1)/2;%midpoint
NN=xm;
MM=xl;
for i=1:m
Z=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z1=Z-1;%0>Z1>-1
ZZ(floor(i))=Z;
ZZZ(i)=Z-Z1;
while (Z-Z1) > 3d-14
p1=1;
p2=0;
for j=1:NMAX
p3=p2;
p2=p1;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p1=((2*j-1)*Z*p2-(j-1)*p3)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(Z*p1-p2)/(Z^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z1=Z;
Z=Z1-p1/pp;
end
x(i)=xm-xl*Z;%x1<x<(x2+x1)/2
x(NMAX+1-i)=xm+xl*Z;%x2>x>(x2+x1)/2
w(i)=2*xl/((1-Z^2)*pp^2);%(x2-x1)/2
w(NMAX+1-i)=w(i);
end
for i=1:NMAX
u(i)=x(i);
end
%%
%The integration of phi
x22=2.*pi;%the high limit of the integration
x11=0;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
mm=(NMAX+1)/2;%%？
xmm=(x22+x11)/2;%midpoint 
xll=(x22-x11)/2;%midpoint
NN=xmm;
MM=xll;
for i=1:mm
ZS=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z11=ZS-1;%0>Z1>-1
ZZ1(floor(i))=ZS;
ZZZ1(i)=ZS-Z11;
while (ZS-Z11) > 3d-14
p11=1;
p22=0;
for j=1:NMAX
p33=p22;
p22=p11;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p11=((2*j-1)*ZS*p22-(j-1)*p33)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(ZS*p11-p22)/(ZS^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z11=ZS;
ZS=Z11-p11/pp;
end
y(i)=xmm-xll*ZS;%x1<x<(x2+x1)/2
y(NMAX+1-i)=xmm+xll*ZS;%x2>x>(x2+x1)/2
q(i)=2*xll/((1-ZS^2)*pp^2);%(x2-x1)/2
q(NMAX+1-i)=q(i);
end
for i=1:NMAX
v(i)=y(i);
end
PFF11 = zeros(NMAX,NMAX);
PFF22 = zeros(NMAX,NMAX);
PFF33 = zeros(NMAX,NMAX);
PFF12 = zeros(NMAX,NMAX);
PFF13 = zeros(NMAX,NMAX);
PFF21 = zeros(NMAX,NMAX);
PFF23 = zeros(NMAX,NMAX);
PFF31 = zeros(NMAX,NMAX);
PFF32 = zeros(NMAX,NMAX);
PFF44 = zeros(NMAX,NMAX);
PFF55 = zeros(NMAX,NMAX);
PFF66 = zeros(NMAX,NMAX);
% u(1) = 0;
% u(end) = pi;
% v(1) = 0;
% v(end) = 2*pi;
for I = 1:NMAX
    for J = 1:NMAX
        y = sin(u(I)).*cos(v(J));
        z = sin(u(I)).*sin(v(J));
        x = cos(u(I));
        PF = w(I).*q(J).*sin(u(I)).*HHMATRIX1(C,x,y,z,r,gama)./4;
        PFF11(I,J) = PF(1,1);
        PFF22(I,J) = PF(2,2);
        PFF33(I,J) = PF(3,3);
        PFF12(I,J) = PF(1,2);
        PFF13(I,J) = PF(1,3);
        PFF21(I,J) = PF(2,1);
        PFF23(I,J) = PF(2,3);
        PFF31(I,J) = PF(3,1);
        PFF32(I,J) = PF(3,2);
        PFF44(I,J) = PF(4,4);
        PFF55(I,J) = PF(5,5);
        PFF66(I,J) = PF(6,6);
    end
end
P(1,1) = sum(sum(PFF11));
P(2,2) = sum(sum(PFF22));
P(3,3) = sum(sum(PFF33));
P(1,2) = sum(sum(PFF12));
P(1,3) = sum(sum(PFF13));
P(2,1) = sum(sum(PFF21));
P(2,3) = sum(sum(PFF23));
P(3,1) = sum(sum(PFF31));
P(3,2) = sum(sum(PFF32));
P(4,4) = sum(sum(PFF44));
P(5,5) = sum(sum(PFF55));
P(6,6) = sum(sum(PFF66));
end