%This code is used to calculate the inflence of inclusion on elastic moduli
function [D11c D12c D13c D22c D23c D33c] = DINSTRAININ11(Db,Kb,vb,arflow,arflow02,arf02,GAMA01,NMAX)
%%
Kpb = Kb;
vpb=vb; %Poisson ratio
%%
%The integration of arelow02
x2=0.99999;%the high limit of the integration
x1=arflow02;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
m=(NMAX+1)/2;%%？
xm=(x2+x1)/2;%midpoint 
xl=(x2-x1)/2;%midpoint
NN=xm;
MM=xl;
for i=1:m
Z=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z1=Z-1;%0>Z1>-1
ZZ(floor(i))=Z;
ZZZ(i)=Z-Z1;
while (Z-Z1) > 3d-14
p1=1;
p2=0;
for j=1:NMAX
p3=p2;
p2=p1;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p1=((2*j-1)*Z*p2-(j-1)*p3)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(Z*p1-p2)/(Z^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z1=Z;
Z=Z1-p1/pp;
end
x(i)=xm-xl*Z;%x1<x<(x2+x1)/2
x(NMAX+1-i)=xm+xl*Z;%x2>x>(x2+x1)/2
w(i)=2*xl/((1-Z^2)*pp^2);%(x2-x1)/2
w(NMAX+1-i)=w(i);
end
for i=1:NMAX
u(i)=x(i);
end
%%
%The discreatation of arelow
x22=0.9999;%the high limit of the integration
x11=arflow;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
mm=(NMAX+1)/2;%%？
xmm=(x22+x11)/2;%midpoint 
xll=(x22-x11)/2;%midpoint
NN=xmm;
MM=xll;
for i=1:mm
ZS=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z11=ZS-1;%0>Z1>-1
ZZ1(floor(i))=ZS;
ZZZ1(i)=ZS-Z11;
while (ZS-Z11) > 3d-14
p11=1;
p22=0;
for j=1:NMAX
p33=p22;
p22=p11;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p11=((2*j-1)*ZS*p22-(j-1)*p33)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(ZS*p11-p22)/(ZS^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z11=ZS;
ZS=Z11-p11/pp;
end
y(i)=xmm-xll*ZS;%x1<x<(x2+x1)/2
y(NMAX+1-i)=xmm+xll*ZS;%x2>x>(x2+x1)/2
q(i)=2*xll/((1-ZS^2)*pp^2);%(x2-x1)/2
q(NMAX+1-i)=q(i);
end
for i=1:NMAX
v(i)=y(i);
end
%%
%the fracture porosity
cc = zeros(1,NMAX);
for I=1:NMAX
cc(I)=(pi.^2.*Kpb.*(1-2.*vpb).*v(I).*GAMA01./((1-vpb.^2).*p).*exp(-(3.*pi.*Kpb.*(1-2.*vpb).*(v(I)))./(4.*(1-vpb.^2).*p))).*(1-arf02./v(I)).*q(I);
end
sumffcb=1-sum(sum(cc));
%Calculate the elastic modulus
CcIF11 = zeros(1,NMAX);
% CcIF66 = zeros(1,NMAX);
CcIF44 = zeros(1,NMAX);
Qcrs = zeros(1,NMAX);
Gcrs = zeros(1,NMAX);
phiC = zeros(1,NMAX);
for I=1:NMAX
Dc = zeros
Pcc = Pc(Qb,Gb,u(I),arf02);
% DDIN01 = (Dc-Db);
DDIN = inv((Dc-Db));
DcIN01 = inv((DDIN+sumffcb.*Pcc));
DcIN = ROTAIN(DcIN01,200);
CcIFM = (pi.^2.*Kpb.*(1-2.*vpb).*u(I).*GAMA01./((1-vpb.^2).*p).*exp(-(3.*pi.*Kpb.*(1-2.*vpb).*(u(I)))./(4.*(1-vpb.^2).*p))).*(1-arf02./u(I)).*DcIN.*w(I);
Qcrs(I) = CcIFM(1,1);
Gcrs(I) = CcIFM(1,2);
phiC(I) = CcIFM(4,4);
CcIF11(I) = CcIFM(1,1);
% CcIF12(I) = CcIFM(1,2);
% CcIF13(I) = CcIFM(1,3);
% CcIF21(I) = CcIFM(2,1);
% CcIF22(I) = CcIFM(2,2);
% CcIF23(I) = CcIFM(2,3);
% CcIF31(I) = CcIFM(3,1);
% CcIF32(I) = CcIFM(3,2);
% CcIF33(I) = CcIFM(3,3);
CcIF44(I) = CcIFM(4,4);
% CcIF55(I) = CcIFM(5,5);
% CcIF66(I) = CcIFM(6,6);
end
Qcin = sum(CcIF11);
Gcin = sum(CcIF44);
Qcrr = sum(Qcrs);
Gcrr = sum(Gcrs);
phiCC = sum(phiC);
phiBB = sumffcb;
end