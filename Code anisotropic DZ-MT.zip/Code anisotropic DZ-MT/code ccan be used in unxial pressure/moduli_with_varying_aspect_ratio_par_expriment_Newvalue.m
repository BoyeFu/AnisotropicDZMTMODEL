%This code is used to calculate the stress denpendent velocity for the
%experiment data
clear
%we want to calculate the calculation time
tic
%%
%Basic parameters
%The parameters for the dry rock
Kb = 6.1;%bulk modulus GPa
mubb = 6.3;%shear modulus GPa
Mbb = Kb+4/3.*mubb;%P-wave modulus GPa
Eb = 9*Kb*mubb/(3*Kb+mubb);%Young's modulus
vb = (3*Kb-2*mubb)/(2*(3*Kb+mubb));%Poisson's ratio
%%
%%
% mb = 0;%3oECs of background unit GPa
% nb = 0;%3oECs of background unit GPa
% lb = 0;%3oECs of background unit GPa
%%
rho = 2090;%density kg/m^3
p011 = 500/1000;%unit GPa
GAMA01 = 0.020;%the initial
NMAX01 = 200;
p022 = 500/1000;%unit GPa
GAMA02 = 0.020;%the initial
NMAX02 = 200;
p033 = 500/1000;%unit GPa
GAMA03 = 0.020;%the initial
NMAX03 = 200;
%%
%Experiment data
Pd1 = [0.000 	0.803 	1.338 	1.740 	2.409 	3.000 	4.000 	6.000 	8.000 	10.000 	12.000];%differential stress in 1 direction, unit MPa
VP = [2600.000 	2650.000 	2680.000 	2710.000 	2720.000 	2750.000 	2750.000 	2770.000 	2780.000 	2790.000 	2790.000];%P-wave velocity in the direction normal to the stress, m/s
VS1 = [1700.000 	1800.000 	1840.000 	1870.000 	1910.000 	1940.000 	1980.000 	2040.000 	2080.000 	2110.000 	2140.000];%S-wave velocity in the direction normal to the stress, polarization parallel to surface,m/s
VS2 = [1700.000 	1750.000 	1780.000 	1800.000 	1820.000 	1850.000 	1860.000 	1880.000 	1900.000 	1900.000 	1910.000];%S-wave velocity in the direction normal to the stress, polarization normal to surface,m/s
D22e = rho.*VP.^2./1000000000;%D11 value unit GPa
D55e = rho.*VS1.^2./1000000000;%D44e value unit GPa
D44e = rho.*VS2.^2./1000000000;%D55e value unit GPa
D22EE=D22e.*Eb;
D44EE=D44e.*Eb;
D55EE=D55e.*Eb;
CE22 = polyfit(-Pd1(5:9)/1000,D22EE(5:9),1);
CE44 = polyfit(-Pd1(5:9)/1000,D44EE(5:9),1);
CE55 = polyfit(-Pd1(5:9)/1000,D55EE(5:9),1);
Mb = CE22(2)./Eb;
% Mb = Mbb;
mub = (CE44(2)+CE55(2))./Eb./2;
% mub = mubb;
mub44 = CE44(2)./Eb;
mub55 = CE55(2)./Eb;
A=[-4*vb 0 (2-4*vb);(1-2*vb) -1/2 0;(1-2*vb) 1/2*vb 0];
B=[CE22(1)-(1-6*vb)*Mb-2*(vb-1)*mub;CE44(1)-(1-2*vb)*Mb+2*(1+vb)*mub;CE55(1)-(1-2*vb)*Mb];
EE=A\B;
mb = EE(1);
nb = EE(2);
lb = EE(3);
%%
%Unxial stress
Pd11 = (0:0.2:12);%Unxial stress
Pd22 = zeros(1,length(Pd11));
Pd33 = zeros(1,length(Pd11));
%%
%in this research, the compressed force should be negetive value, the
%Stretch force should be positive value
e1 = -Pd11./Eb/1000;%The strain in 1 direction
e2 = -Pd11.*(-vb)./Eb./1000;%The strain in 2 direction
% e1 = zeros(1,length(Pd1));
% e2 = zeros(1,length(Pd1));
%%
%Basic parameters
%%
% mb = -14435;%3oECs of background unit GPa
% nb = -17530;%3oECs of background unit GPa
% lb = -7900;%3oECs of background unit GPa
%%
% mb = -4342.32517913922;%3oECs of background unit GPa
% nb = -3997.39902661203;%3oECs of background unit GPa
% lb = -2358.46966635022;%3oECs of background unit GPa
%%
%The third order elastic constant of air
%%
%To deal with the saturated background medium
% are0110 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pd1(end);
% NMAX = 200;%The interval of the discrete
% phi = 0.04;%The total porosity of the rock
% PHIC = phic(Mb,mub,are0110,are0110,GAMA01,p,NMAX);
%%

%%
%%
%we will model the elastic modulus variation of the dry sample
LE = length(e1);%The length of strain, and for every strain, we will have a increase of the elastic moduli
are011 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pd11/1000;
are022 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pd22/1000;
are033 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pd33/1000;
PHIF11 = zeros(1,LE);
PHIF22 = zeros(1,LE);
PHIF33 = zeros(1,LE);
parfor JJ = 1:LE
PHIF11(JJ) = phicF(Mb,mub,are011(JJ),are011(JJ),GAMA01,p011,NMAX01);
PHIF22(JJ) = phicF(Mb,mub,are022(JJ),are022(JJ),GAMA02,p022,NMAX02);
PHIF33(JJ) = phicF(Mb,mub,are033(JJ),are033(JJ),GAMA03,p033,NMAX03);
end
% Qb = zeros(1,LE);
% Gb = zeros(1,LE);
%%
%The background medium elastic moduli
D11b = Mb+(5.*Mb+2.*lb+4.*mb).*e1+2.*(Mb-2.*mub+2.*lb).*e2;
D22b = Mb+(Mb-2.*mub+2.*lb).*e1+(6.*Mb-2.*mub+4.*lb+4.*mb).*e2;
D33b = D22b;
D12b = Mb-2.*mub+(2.*Mb-4.*mub+2.*lb).*e1+(2.*Mb-4.*mub+4.*lb-2.*mb+nb).*e2;
D13b = D12b;
D44b = mub+(Mb-2.*mub+mb-1/2.*nb).*e1+(2.*Mb+2.*mub+2.*mb).*e2;
D55b = mub+(Mb+mb).*e1+(2.*Mb+2.*mb-1/2.*nb).*e2;
D66b = D55b;
D23b = D22b-2.*D44b;
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
D11c1 = zeros(1,LE);
D12c1 = zeros(1,LE);
D13c1 = zeros(1,LE);
D22c1 = zeros(1,LE);
D23c1 = zeros(1,LE);
D33c1 = zeros(1,LE);
D44c1 = zeros(1,LE);
D55c1 = zeros(1,LE);
D66c1 = zeros(1,LE);
%%
D11c2 = zeros(1,LE);
D12c2 = zeros(1,LE);
D13c2 = zeros(1,LE);
D22c2 = zeros(1,LE);
D23c2 = zeros(1,LE);
D33c2 = zeros(1,LE);
D44c2 = zeros(1,LE);
D55c2 = zeros(1,LE);
D66c2 = zeros(1,LE);
%%
D11c3 = zeros(1,LE);
D12c3 = zeros(1,LE);
D13c3 = zeros(1,LE);
D22c3 = zeros(1,LE);
D23c3 = zeros(1,LE);
D33c3 = zeros(1,LE);
D44c3 = zeros(1,LE);
D55c3 = zeros(1,LE);
D66c3 = zeros(1,LE);
%%
%porosity
phic11 = zeros(1,LE);
phic22 = zeros(1,LE);
phic33 = zeros(1,LE);
%%
NMAX = 200;
% parfor II = 1:LE
%     [D11c1(II),D12c1(II),D13c1(II),D22c1(II),D23c1(II),D33c1(II),D44c1(II),D55c1(II),D66c1(II),phic11(II)] = DINSTRAININ11(D11b(II),D12b(II),D13b(II),D22b(II),D23b(II),D33b(II),D44b(II),D55b(II),D66b(II),Kb,vb,are011(II),are011(II),are011(II),GAMA01,p011,NMAX);
% %     [D11c1(II),D12c1(II),D13c1(II),D22c1(II),D23c1(II),D33c1(II),D44c1(II),D55c1(II),D66c1(II)] = DINSTRAININF111(Kb,vb,D11b(II),D12b(II),D13b(II),D22b(II),D23b(II),D33b(II),D44b(II),D55b(II),D66b(II),are011(II),are011(II),are011(II),GAMA01,p011,NMAX);
%     [D11c2(II),D12c2(II),D13c2(II),D22c2(II),D23c2(II),D33c2(II),D44c2(II),D55c2(II),D66c2(II),phic22(II)] = DINSTRAININ22(D11b(II),D12b(II),D13b(II),D22b(II),D23b(II),D33b(II),D44b(II),D55b(II),D66b(II),Kb,vb,are022(II),are022(II),are022(II),GAMA02,p022,NMAX);
%     [D11c3(II),D12c3(II),D13c3(II),D22c3(II),D23c3(II),D33c3(II),D44c3(II),D55c3(II),D66c3(II),phic33(II)] = DINSTRAININ33(D11b(II),D12b(II),D13b(II),D22b(II),D23b(II),D33b(II),D44b(II),D55b(II),D66b(II),Kb,vb,are033(II),are033(II),are033(II),GAMA03,p033,NMAX);
% end
parfor II = 1:LE
    [D11c1(II),D12c1(II),D13c1(II),D22c1(II),D23c1(II),D33c1(II),D44c1(II),D55c1(II),D66c1(II),phic11(II)] = DINSTRAININ11(D11b(II),D12b(II),D13b(II),D22b(II),D23b(II),D33b(II),D44b(II),D55b(II),D66b(II),Kb,vb,are011(II),are011(II),are011(II),GAMA01,p011,NMAX,PHIF22(II),PHIF33(II));
%     [D11c1(II),D12c1(II),D13c1(II),D22c1(II),D23c1(II),D33c1(II),D44c1(II),D55c1(II),D66c1(II)] = DINSTRAININF111(Kb,vb,D11b(II),D12b(II),D13b(II),D22b(II),D23b(II),D33b(II),D44b(II),D55b(II),D66b(II),are011(II),are011(II),are011(II),GAMA01,p011,NMAX);
    [D11c2(II),D12c2(II),D13c2(II),D22c2(II),D23c2(II),D33c2(II),D44c2(II),D55c2(II),D66c2(II),phic22(II)] = DINSTRAININ22(D11b(II),D12b(II),D13b(II),D22b(II),D23b(II),D33b(II),D44b(II),D55b(II),D66b(II),Kb,vb,are022(II),are022(II),are022(II),GAMA02,p022,NMAX,PHIF11(II),PHIF33(II));
    [D11c3(II),D12c3(II),D13c3(II),D22c3(II),D23c3(II),D33c3(II),D44c3(II),D55c3(II),D66c3(II),phic33(II)] = DINSTRAININ33(D11b(II),D12b(II),D13b(II),D22b(II),D23b(II),D33b(II),D44b(II),D55b(II),D66b(II),Kb,vb,are033(II),are033(II),are033(II),GAMA03,p033,NMAX,PHIF11(II),PHIF22(II));
end
D11d = D11b+D11c1+D11c2+D11c3;
D12d = D12b+D12c1+D12c2+D12c3;
D13d = D13b+D13c1+D13c2+D13c3;
D22d = D22b+D22c1+D22c2+D22c3;
D23d = D23b+D23c1+D23c2+D23c3;
D33d = D33b+D33c1+D33c2+D33c3;
D44d = D44b+D44c1+D44c2+D44c3;
D55d = D55b+D55c1+D55c2+D55c3;
D66d = D66b+D66c1+D66c2+D66c3;
%%
% %We will deal with the saturated sample
% Qbsat = zeros(1,LE);
% Gbsat = zeros(1,LE);
T = toc;
%%
figure(1)
% plot(Pd1,D22e)
% hold on
plot(Pd11,D11d)
% legend('Experiment value (D22)','Theoretical value (D22)')
legend('Theoretical value (D11)')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')

figure(2)
plot(Pd1,D44e)
hold on
plot(Pd11,D44d)
legend('Experiment value (D44)','Theoretical value (D44)')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')

figure(3)
plot(Pd1,D55e)
hold on
plot(Pd11,D66d)
legend('Experiment value (D66)','Theoretical value (D66)')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
figure(6)
plot(Pd11,phic11*100)
hold on
plot(Pd11,phic22*100)
hold on
plot(Pd11,phic33*100)
legend('X-direction','Y-direction','Z-direction')
xlabel('Differential pressure (MPa)')
ylabel('Porosity (%)')
%%
save('fildata.mat','Pd11','Pd1','D22e','D22d','D11d','D33d','D44e','D44d','D55e','D55d','D12d','D66d','phic11','phic22','phic33');
%%

%%
