%This code is used to calculate the inflence of inclusion on elastic moduli
function [D11c2,D12c2,D13c2,D22c2,D23c2,D33c2,D44c2,D55c2,D66c2,phic22] = DINSTRAININ22(D11b,D12b,D13b,D22b,D23b,D33b,D44b,D55b,D66b,Kb,vb,arflow02,arflow022,arf022,GAMA02,p022,NMAX,phi11,phi33)
%%
Kpb = Kb;
vpb=vb; %Poisson ratio
Db=[D11b D12b D13b 0 0 0;D12b D22b D23b 0 0 0;D13b D23b D33b 0 0 0;0 0 0 D44b 0 0;0 0 0 0 D55b 0;0 0 0 0 0 D66b];
%%
%The integration of arelow02
x2=0.99999;%the high limit of the integration
x1=arflow022;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
m=(NMAX+1)/2;%%�?
xm=(x2+x1)/2;%midpoint 
xl=(x2-x1)/2;%midpoint
NN=xm;
MM=xl;
for i=1:m
Z=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z1=Z-1;%0>Z1>-1
ZZ(floor(i))=Z;
ZZZ(i)=Z-Z1;
while (Z-Z1) > 3d-14
p1=1;
p2=0;
for j=1:NMAX
p3=p2;
p2=p1;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p1=((2*j-1)*Z*p2-(j-1)*p3)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(Z*p1-p2)/(Z^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z1=Z;
Z=Z1-p1/pp;
end
x(i)=xm-xl*Z;%x1<x<(x2+x1)/2
x(NMAX+1-i)=xm+xl*Z;%x2>x>(x2+x1)/2
w(i)=2*xl/((1-Z^2)*pp^2);%(x2-x1)/2
w(NMAX+1-i)=w(i);
end
for i=1:NMAX
u(i)=x(i);
end
%%
%The discreatation of arelow
x22=0.9999;%the high limit of the integration
x11=arflow02+1e-04;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
mm=(NMAX+1)/2;%%�?
xmm=(x22+x11)/2;%midpoint 
xll=(x22-x11)/2;%midpoint
NN=xmm;
MM=xll;
for i=1:mm
ZS=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z11=ZS-1;%0>Z1>-1
ZZ1(floor(i))=ZS;
ZZZ1(i)=ZS-Z11;
while (ZS-Z11) > 3d-14
p11=1;
p22=0;
for j=1:NMAX
p33=p22;
p22=p11;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p11=((2*j-1)*ZS*p22-(j-1)*p33)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(ZS*p11-p22)/(ZS^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z11=ZS;
ZS=Z11-p11/pp;
end
y(i)=xmm-xll*ZS;%x1<x<(x2+x1)/2
y(NMAX+1-i)=xmm+xll*ZS;%x2>x>(x2+x1)/2
q(i)=2*xll/((1-ZS^2)*pp^2);%(x2-x1)/2
q(NMAX+1-i)=q(i);
end
for i=1:NMAX
v(i)=y(i);
end
%%
%the fracture porosity
cc22 = zeros(1,NMAX);
for I=1:NMAX
cc22(I)=(3.*pi.^2.*Kpb.*(1-2.*vpb).*v(I).*GAMA02./((1-vpb.^2).*p022).*exp(-(9.*pi.*Kpb.*(1-2.*vpb).*(v(I)))./(4.*(1-vpb.^2).*p022))).*(1-arf022./v(I)).*q(I);
end
phic22 = sum(sum(cc22));
sumffcb=1-phic22-phi11-phi33;
%Calculate the elastic modulus
CcIF11 = zeros(1,NMAX);
CcIF12 = zeros(1,NMAX);
CcIF13 = zeros(1,NMAX);
CcIF22 = zeros(1,NMAX);
CcIF23 = zeros(1,NMAX);
CcIF33 = zeros(1,NMAX);
CcIF44 = zeros(1,NMAX);
CcIF55 = zeros(1,NMAX);
CcIF66 = zeros(1,NMAX);
for I=1:NMAX
Dc = zeros(6,6);
% Pc = PMATRIX1(Db,1,u(I)-arf022,200);
Pc = PMATRIX2(Db,1,u(I),arf022);
% Pcc = PMATRIX3(Db,1,u(I),arf022);
Pcc = ROTA(Pc,pi/2,0);
% DDIN01 = (Dc-Db);
DDIN = inv((Dc-Db));
DcIN01 = inv((DDIN+sumffcb.*Pcc));
DcIN = DcIN01;
% CcIFM = (3.*pi.^2.*Kpb.*(1-2.*vpb).*u(I).*GAMA02./((1-vpb.^2).*p022).*exp(-(9.*pi.*Kpb.*(1-2.*vpb).*(u(I)))./(4.*(1-vpb.^2).*p022))).*(1-arf022./u(I)).*DcIN.*w(I);
CcIFM = (pi.^2.*Kpb.*(1-2.*vpb).*u(I).*GAMA02./((1-vpb.^2).*p022).*exp(-(3.*pi.*Kpb.*(1-2.*vpb).*(u(I)))./(4.*(1-vpb.^2).*p022))).*(1-arf022./u(I)).*DcIN.*w(I);
CcIF11(I) = CcIFM(1,1);
CcIF12(I) = CcIFM(1,2);
CcIF13(I) = CcIFM(1,3);
CcIF22(I) = CcIFM(2,2);
CcIF23(I) = CcIFM(2,3);
CcIF33(I) = CcIFM(3,3);
CcIF44(I) = CcIFM(4,4);
CcIF55(I) = CcIFM(5,5);
CcIF66(I) = CcIFM(6,6);
end
D11c2 = sum(CcIF11);
D12c2 = sum(CcIF12);
D13c2 = sum(CcIF13);
D22c2 = sum(CcIF22);
D23c2 = sum(CcIF23);
D33c2 = sum(CcIF33);
D44c2 = sum(CcIF44);
D55c2 = sum(CcIF55);
D66c2 = sum(CcIF66);
end