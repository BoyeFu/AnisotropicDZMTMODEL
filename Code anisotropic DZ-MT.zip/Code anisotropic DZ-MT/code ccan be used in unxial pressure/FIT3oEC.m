%This code is used to calculate the stress denpendent velocity for the
%experiment data
clear
%we want to calculate the calculation time
tic
%%
%Basic parameters
%The parameters for the dry rock
Kb = 6.1;%bulk modulus GPa
mub = 6.5;%shear modulus GPa
Mb = Kb+4/3.*mub;%P-wave modulus GPa
Eb = 9*Kb*mub/(3*Kb+mub);%Young's modulus
vb = (3*Kb-2*mub)/(2*(3*Kb+mub));%Poisson's ratio
mb = -14435;%3oECs of background unit GPa
nb = -17530;%3oECs of background unit GPa
lb = -7900;%3oECs of background unit GPa
rho = 2090;%density kg/m^3
p = 9/1000;%unit GPa
GAMA01 = 0.626;%the initial
%%
%Experiment data
Pd1 = [0.000 	0.803 	1.338 	1.740 	2.409 	3.000 	4.000 	6.000 	8.000 	10.000 	12.000];%differential stress in 1 direction, unit MPa
Pd2 = zeros(1,length(Pd1));
Pd3 = zeros(1,length(Pd1));
VP = [2600.000 	2650.000 	2680.000 	2710.000 	2720.000 	2750.000 	2750.000 	2770.000 	2780.000 	2790.000 	2790.000];%P-wave velocity in the direction normal to the stress, m/s
VS1 = [1700.000 	1800.000 	1840.000 	1870.000 	1910.000 	1940.000 	1980.000 	2040.000 	2080.000 	2110.000 	2140.000];%S-wave velocity in the direction normal to the stress, polarization parallel to surface,m/s
VS2 = [1700.000 	1750.000 	1780.000 	1800.000 	1820.000 	1850.000 	1860.000 	1880.000 	1900.000 	1900.000 	1910.000];%S-wave velocity in the direction normal to the stress, polarization normal to surface,m/s
D22e = rho.*VP.^2./1000000000;%D11 value unit GPa
D55e = rho.*VS1.^2./1000000000;%D44e value unit GPa
D44e = rho.*VS2.^2./1000000000;%D55e value unit GPa
D22EE=D22e.*Eb;
D44EE=D44e.*Eb;
D55EE=D55e.*Eb;
CE22 = polyfit(-Pd1(7:10)/1000,D22EE(7:10),1);
CE44 = polyfit(-Pd1(7:10)/1000,D44EE(7:10),1);
CE55 = polyfit(-Pd1(7:10)/1000,D55EE(7:10),1);
Mbb = CE22(2)./Eb;
mubb= (CE44(2)+CE55(2))./Eb./2;
mubb44 = CE44(2)./Eb;
mubb55 = CE55(2)./Eb;
A=[-4*vb 0 (2-4*vb);(1-2*vb) -1/2 0;(1-2*vb) 1/2*vb 0];
B=[CE22(1)-(1-6*vb)*Mb-2*(vb-1)*mub;CE44(1)-(1-2*vb)*Mb+2*(1+vb)*mub;CE55(1)-(1-2*vb)*Mb];
EE=A\B;
figure(1)
plot(Pd1,D22e)
figure(2)
plot(Pd1,D44e)
figure(3)
plot(Pd1,D55e)