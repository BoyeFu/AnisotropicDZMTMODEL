clear
EEE = [2 1 1 0 0 0;1 2 1 0 0 0;1 1 2 0 0 0;0 0 0 1/2 0 0;0 0 0 0 1/2 0;0 0 0 0 0 1/2];
EEER = ROTAIN(EEE,1000)
EERR = sum(EEE(:))
