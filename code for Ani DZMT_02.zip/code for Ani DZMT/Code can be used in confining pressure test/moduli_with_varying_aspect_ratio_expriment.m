%This code is used to calculate the stress denpendent velocity for the
%experiment data
clear
%we want to calculate the calculation time
tic
%%
%Basic parameters
%The parameters for quatz
Kgr = 37; %Bulk modulus of quatz
mugr = 44; %Shear modulus of quatz
Mca = 1.01e-04;%the P-wave modulus of air unit GPa
muca = 0;%Shear modulus of aire
Mcw = 2.25;%The P-wave modulus (bulk modulus) of water
mucw = 0;%Shear moudlus of water
p = 13/1000;%unit GPa
GAMA01 = 0.125;%the initial
%%
Qe = [68.2060261	76.06422991	80.11812245	82.29214812	83.95543008	84.2983426	85.1009935	85.36280653	86.12845332	86.60218738	87.41570662	87.04567013	87.35278678	87.61744119	87.88279495	88.40420812	87.86156384	88.42550468];%P-wave modulus in experiment
Ge = [32.36420043	35.54222229	37.19481967	38.14358006	38.57982943	39.03549843	39.17034494	39.80075747	39.62867454	39.93591024	39.84927331	40.1401805	40.07048438	40.06947473	40.36118311	40.2050826	40.37658683	40.35834591];% S-wave modulus in experiment
KKE = Qe-4./3*Ge;
Qew = [80.92979739	83.49201885	85.54556605	86.22338567	86.60652653	87.45861972	87.6740257	87.93250082	88.02025186	88.15090399	88.19618715	88.58368154	88.84349311	88.88865068	89.10580948	89.15133721	89.06787859	89.45728109];%P-wave modulus saturated with water
Gew = [35.2706331	37.25269447	38.34890811	38.91159889	39.08285335	39.27160712	39.58167839	39.65088366	39.85825323	39.82375552	40.03177948	39.94496924	40.18815307	40.48422071	40.46683504	40.39692102	40.34483148	40.46683504];%S-wave modulus saturated with water
Ke = Qe-4/3*Ge;
eexp = [0.000144449	0.000288897	0.000433346	0.000577795	0.000722243	0.000866692	0.001011141	0.001155589	0.001300038	0.001444487	0.001588935	0.001733384	0.001877832	0.002022281	0.00216673	0.002311178	0.002455627	0.002600076]./3;
e=(0.0001:0.0001:0.0026)./3;%The strain or theoritical value
K0 = Ke(end);
Pee = 3.*eexp.*K0; %Confining pressure,unit GPa
Pet = 3.*e.*K0;%The theoretical confining pressure
%Caculate the third-order elastic constant of the experiment
%The third-order elstic constants for P-wave modulus for background medium
[TOEP,QQ0] = polyfit(eexp(10:18),Qe(10:18),1);
PHI01 = -TOEP(1);%This is the third-order elastic constant for P-wave modulus
Mb = TOEP(2);%The P-wave modulus when the pressure is zero
%The third-order elstic constants for shear modulus for background medium
[TOES,GG0] = polyfit(eexp(10:18),Ge(10:18),1);
PHI02 = -TOES(1);%This is the third-order elastic constant for shear modulus
mub = TOES(2);%The background shear modulus when the pressure is zero
Kb = Mb-4./3.*mub;%The bulk moudulus of background medium when the pressure is at zero
vb=(Mb-2*mub)/(2*(Mb-mub)); %Poisson ratio
%%
%The third order elastic constant of air
l1 = -1; %TOE unit GPa
m1 = -1.01e-4; %TOE unit GPa
n1 = 0; %TOE unit GPa
PHI11ca = 7*Mca-4*muca+6*l1+4*m1;
PHI12ca = 0;
%%
%The third-order elastic constant of water
PHI11cw = -33.52;%unit GPa
PHI12cw = 0;
%%
%To deal with the saturated background medium
arf = 1-Kb./Kgr;%Biot-Willis coefficient
are020 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pet(18);
NMAX = 200;%The interval of the discrete
phi = 0.04;%The total porosity of the rock
PHIC = phic(Mb,mub,are020,are020,GAMA01,p,NMAX);
%%
% % A test function
% a = (0:1e-05:5e-03);
% cc = zeros(1,length(a));
% for II = 1:length(a)
% %     if a(II)<=are020
% %         cc(II)=0;
% %     else
% cc(II)=(pi.^2.*Kb.*(1-2.*vb).*a(II).*GAMA01./((1-vb.^2).*p).*exp(-(3.*pi.*Kb.*(1-2.*vb).*(a(II)))./(4.*(1-vb.^2).*p))).*(1-are020./a(II));
% %     end
% end
%     plot(a,cc)
%%
phib = phi-PHIC;%The stiff porosity
MM = ((arf-phib)./Kgr+phib./Mcw).^(-1);
Mbsat = Mb+arf.^2.*MM;%The saturated background bulk modulus
mubsat = mub;%The saturated background shear modulus
%%
%we will model the elastic modulus variation of the dry sample
LE = length(e);%The length of strain, and for every strain, we will have a increase of the elastic moduli
are02 = 4.*(1-vb.^2)./(3.*pi.*Kb.*(1-2.*vb)).*Pet;
Qb = zeros(1,LE);
Gb = zeros(1,LE);
OMIGB01b = zeros(6,6,LE);
OMIGBMb = zeros(6,6,LE);
OMIGBb = zeros(1,LE);
for i = 1:LE
OMIGB01b(:,:,i) = OMIGbINFI(Mb,mub,Mca,muca,are02(i),are02(i),GAMA01,p,NMAX);
OMIGBMb(:,:,i) = ROTAIN(OMIGB01b(:,:,i),NMAX);
OMIGBb(i) = OMIGBMb(1,1,i)+OMIGBMb(1,2,i)+OMIGBMb(1,3,i);
%%
%The background medium elastic moduli
Qb(i) = Mb-PHI01.*OMIGBb(i).*e(i);
Gb(i) = mub-PHI02.*OMIGBb(i).*e(i);
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
end
Qcain = zeros(1,LE);
Gcain = zeros(1,LE);
for i = 1:LE
    [Qcain(i),Gcain(i)] = DINSTRAININ(Qb(i),Gb(i),Mb,mub,Mca,muca,PHI11ca,PHI12ca,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
end
Qd = Qb+Qcain;%The elastic modulus of dry sample P-wave modulus
Gd = Gb+Gcain;%The elastic modulus of dry sample Shear modulus
%%
%We will deal with the saturated sample
Qbsat = zeros(1,LE);
Gbsat = zeros(1,LE);
OMIGB01bsat = zeros(6,6,LE);
OMIGBMbsat = zeros(6,6,LE);
OMIGBbsat = zeros(1,LE);
for i = 1:LE
OMIGB01bsat(:,:,i) = OMIGbINFI(Mb,mub,Mcw,mucw,are02(i),are02(i),GAMA01,p,NMAX);
OMIGBMbsat(:,:,i) = ROTAIN(OMIGB01bsat(:,:,i),NMAX);
OMIGBbsat(i) = OMIGBMbsat(1,1,i)+OMIGBMbsat(1,2,i)+OMIGBMbsat(1,3,i);
%%
%The background medium elastic moduli
Qbsat(i) = Mbsat-PHI01.*OMIGBbsat(i).*e(i);
Gbsat(i) = mubsat-PHI02.*OMIGBbsat(i).*e(i);
%%
%The incluison medium elastic moduli still need the code
%At this stage we should do "for" for the strain "e"
end
Qcwin = zeros(1,LE);
Gcwin = zeros(1,LE);
for i = 1:LE
    [Qcwin(i),Gcwin(i)] = DINSTRAININ(Qb(i),Gb(i),Mb,mub,Mcw,mucw,PHI11cw,PHI12cw,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
end
Qsat = Qbsat+Qcwin;%The elastic modulus of saturated sample P-wave modulus
Gsat = Gbsat+Gcwin;%The elastic modulus of saturated sample Shear modulus
T = toc;
%%
figure(1)
plot(Pee.*1000,Qe)
hold on
plot(Pet.*1000,Qd)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(2)
plot(Pee.*1000,Ge)
hold on
plot(Pet.*1000,Gd)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
%%
figure(3)
plot(Pee.*1000,Qew)
hold on
plot(Pet.*1000,Qsat)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(4)
plot(Pee.*1000,Gew)
hold on
plot(Pet.*1000,Gsat)
legend('Experiment data','Model value')
xlabel('Differential pressure (MPa)')
ylabel('Shear modulus (GPa)')
%%
% %Analyze the linear part
% %%
% %Dry sample
% QLcd = zeros(1,LE);
% GLcd = zeros(1,LE);
% phib = zeros(1,LE);
% parfor i = 1:LE
%     [QLcd(i),GLcd(i),phib(i)] = DLINEAR(Qb(i),Gb(i),Mb,mub,Mca,muca,PHI11ca,PHI12ca,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
% end
% QLd = phib.*Qb+QLcd;
% GLd = phib.*Gb+GLcd;
% %%
% figure(5)
% plot(Pee.*1000,Qe)
% hold on
% plot(Pet.*1000,QLd)
% legend('Experiment data','Model value')
% xlabel('Differential pressure (MPa)')
% ylabel('P-wave modulus (GPa)')
% figure(6)
% plot(Pee.*1000,Ge)
% hold on
% plot(Pet.*1000,GLd)
% legend('Experiment data','Model value')
% xlabel('Differential pressure (MPa)')
% ylabel('Shear modulus (GPa)')
% %%
% %Saturated condition
% QLcsat = zeros(1,LE);
% GLcsat = zeros(1,LE);
% phibsat = zeros(1,LE);
% parfor i = 1:LE
%     [QLcsat(i),GLcsat(i),phibsat(i)] = DLINEAR(Qb(i),Gb(i),Mb,mub,Mcw,mucw,PHI11cw,PHI12cw,are02(i),are02(i),are02(i),GAMA01,p,e(i),NMAX);
% end
% QLsat = phib.*Qbsat+QLcd;
% GLsat = phib.*Gbsat+GLcd;
% %%
% figure(7)
% plot(Pee.*1000,Qew)
% hold on
% plot(Pet.*1000,QLsat)
% legend('Experiment data','Model value')
% xlabel('Differential pressure (MPa)')
% ylabel('P-wave modulus (GPa)')
% figure(8)
% plot(Pee.*1000,Gew)
% hold on
% plot(Pet.*1000,GLsat)
% legend('Experiment data','Model value')
% xlabel('Differential pressure (MPa)')
% ylabel('Shear modulus (GPa)')