%The sries of function is used to calculate the P matrix when the
%background meidum is a VTI medium (C11=C22 C23=C13 C44=C55)
%The function is made from Effective elastic modulus of a transverse isotropy solid with aligned inhomogeneity Xu Song Tang Xiao-Ming Su Yuan-Da Citation: Acta Physica Sinica, 64, 206201 (2015) DOI: 10.7498/aps.64.206201
%The code is used to calculate N matrx
function [N,D] = NMATRIX1(C,x,y,z)
%C is the background stiffness matrix 6*6, x y z are the variable
N = zeros(3,3);
n = sqrt(z.^2+y.^2);
N(3,3) = (C(4,4).*z.^2+C(3,3).*y.^2+C(6,6).*x.^2).*(C(6,6).*n.^2+C(1,1).*x.^2)-(C(1,3)+C(6,6)).^2.*y.^2.*x.^2;
N(2,2) = (C(3,3).*z.^2+C(4,4).*y.^2+C(6,6).*x.^2).*(C(6,6).*n.^2+C(1,1).*x.^2)-(C(1,3)+C(6,6)).^2.*z.^2.*x.^2;
N(1,1) = (C(3,3).*z.^2+C(4,4).*y.^2+C(6,6).*x.^2).*(C(4,4).*z.^2+C(3,3).*y.^2+C(6,6).*x.^2)-(C(3,3)-C(4,4)).^2.*z.^2.*y.^2;
N(3,2) = (C(1,3)+C(6,6)).^2.*z.*y.*x.^2-(C(3,3)-C(4,4)).*z.*y.*(C(6,6).*n.^2+C(1,1).*x.^2);
N(2,3) = N(3,2);
N(1,3) = (C(3,3)-C(4,4)).*(C(1,3)+C(6,6)).*z.*y.^2.*x-(C(1,3)+C(6,6)).*z.*x.*(C(4,4).*z.^2+C(3,3).*y.^2+C(6,6).*x.^2);
N(3,1) = N(1,3);
N(2,1) = (C(3,3)-C(4,4)).*(C(1,3)+C(6,6)).*z.^2.*y.*x-(C(1,3)+C(6,6)).*y.*x.*(C(3,3).*z.^2+C(4,4).*y.^2+C(6,6).*x.^2);
N(1,2) = N(2,1);
D = (C(4,4).*n.^2+C(6,6).*x.^2).*((C(6,6).*n.^2+C(1,1).*x.^2).*(C(3,3).*n.^2+C(6,6).*x.^2)-(C(1,3)+C(6,6)).^2.*n.^2.*x.^2);
end
