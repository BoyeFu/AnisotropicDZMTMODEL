%This code is used to do the integration 
%The variation of the function is a matrix
%MAX is the maxtrix
%cita is angle in the xoy [0,2pi],phi [0,pi]
function ROTAIN = ROTAIN(MAX,NMAX)
%%
%The integration of cita
x2=pi;%the high limit of the integration
x1=0;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
m=(NMAX+1)/2;%%？
xm=(x2+x1)/2;%midpoint 
xl=(x2-x1)/2;%midpoint
NN=xm;
MM=xl;
for i=1:m
Z=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z1=Z-1;%0>Z1>-1
ZZ(floor(i))=Z;
ZZZ(i)=Z-Z1;
while (Z-Z1) > 3d-14
p1=1;
p2=0;
for j=1:NMAX
p3=p2;
p2=p1;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p1=((2*j-1)*Z*p2-(j-1)*p3)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(Z*p1-p2)/(Z^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z1=Z;
Z=Z1-p1/pp;
end
x(i)=xm-xl*Z;%x1<x<(x2+x1)/2
x(NMAX+1-i)=xm+xl*Z;%x2>x>(x2+x1)/2
w(i)=2*xl/((1-Z^2)*pp^2);%(x2-x1)/2
w(NMAX+1-i)=w(i);
end
for i=1:NMAX
u(i)=x(i);
end
%%
%The integration of phi
x22=2.*pi;%the high limit of the integration
x11=0;
% CALCULATE GAUSS-LEGENDRE WEIGHTS, In this paper, we use GAUSS-LEGENDRE
mm=(NMAX+1)/2;%%？
xmm=(x22+x11)/2;%midpoint 
xll=(x22-x11)/2;%midpoint
NN=xmm;
MM=xll;
for i=1:mm
ZS=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z11=ZS-1;%0>Z1>-1
ZZ1(floor(i))=ZS;
ZZZ1(i)=ZS-Z11;
while (ZS-Z11) > 3d-14
p11=1;
p22=0;
for j=1:NMAX
p33=p22;
p22=p11;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p11=((2*j-1)*ZS*p22-(j-1)*p33)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(ZS*p11-p22)/(ZS^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z11=ZS;
ZS=Z11-p11/pp;
end
y(i)=xmm-xll*ZS;%x1<x<(x2+x1)/2
y(NMAX+1-i)=xmm+xll*ZS;%x2>x>(x2+x1)/2
q(i)=2*xll/((1-ZS^2)*pp^2);%(x2-x1)/2
q(NMAX+1-i)=q(i);
end
for i=1:NMAX
v(i)=y(i);
end
for I = 1:NMAX
    for J = 1:NMAX
        FF = w(I).*q(J).*sin(u(I)).*ROTA(MAX,u(I),v(J))./4./pi;
%%
        F11(I,J) = FF(1,1);
        F12(I,J) = FF(1,2);
        F13(I,J) = FF(1,3);
        F14(I,J) = FF(1,4);
        F15(I,J) = FF(1,5);
        F16(I,J) = FF(1,6);
%%
        F21(I,J) = FF(2,1);
        F22(I,J) = FF(2,2);
        F23(I,J) = FF(2,3);
        F24(I,J) = FF(2,4);
        F25(I,J) = FF(2,5);
        F26(I,J) = FF(2,6);
%%
        F31(I,J) = FF(3,1);
        F32(I,J) = FF(3,2);
        F33(I,J) = FF(3,3);
        F34(I,J) = FF(3,4);
        F35(I,J) = FF(3,5);
        F36(I,J) = FF(3,6);
%%
        F41(I,J) = FF(4,1);
        F42(I,J) = FF(4,2);
        F43(I,J) = FF(4,3);
        F44(I,J) = FF(4,4);
        F45(I,J) = FF(4,5);
        F46(I,J) = FF(4,6);
%%
        F51(I,J) = FF(5,1);
        F52(I,J) = FF(5,2);
        F53(I,J) = FF(5,3);
        F54(I,J) = FF(5,4);
        F55(I,J) = FF(5,5);
        F56(I,J) = FF(5,6);
%%
        F61(I,J) = FF(6,1);
        F62(I,J) = FF(6,2);
        F63(I,J) = FF(6,3);
        F64(I,J) = FF(6,4);
        F65(I,J) = FF(6,5);
        F66(I,J) = FF(6,6);
    end
end
%%
FF11 = sum(sum(F11));
FF12 = sum(sum(F12));
FF13 = sum(sum(F13));
FF14 = sum(sum(F14));
FF15 = sum(sum(F15));
FF16 = sum(sum(F16));
%%
FF21 = sum(sum(F21));
FF22 = sum(sum(F22));
FF23 = sum(sum(F23));
FF24 = sum(sum(F24));
FF25 = sum(sum(F25));
FF26 = sum(sum(F26));
%%
FF31 = sum(sum(F31));
FF32 = sum(sum(F32));
FF33 = sum(sum(F33));
FF34 = sum(sum(F34));
FF35 = sum(sum(F35));
FF36 = sum(sum(F36));
%%
FF41 = sum(sum(F41));
FF42 = sum(sum(F42));
FF43 = sum(sum(F43));
FF44 = sum(sum(F44));
FF45 = sum(sum(F45));
FF46 = sum(sum(F46));
%%
FF51 = sum(sum(F51));
FF52 = sum(sum(F52));
FF53 = sum(sum(F53));
FF54 = sum(sum(F54));
FF55 = sum(sum(F55));
FF56 = sum(sum(F56));
%%
FF61 = sum(sum(F61));
FF62 = sum(sum(F62));
FF63 = sum(sum(F63));
FF64 = sum(sum(F64));
FF65 = sum(sum(F65));
FF66 = sum(sum(F66));
ROTAIN = [FF11 FF12 FF13 FF14 FF15 FF16;FF21 FF22 FF23 FF24 FF25 FF26;FF31 FF32 FF33 FF34 FF35 FF36;FF41 FF42 FF43 FF44 FF45 FF46;FF51 FF52 FF53 FF54 FF55 FF56;FF61 FF62 FF63 FF64 FF65 FF66];
end