%This code is used to shown the result
clear
%%
%Load the data
load('fildata.mat');
%%
%Plot the result
figure(1)
plot(Pd1,D22e)
hold on
plot(Pd11,D22d)
legend('Experiment data','Analytical result')
xlabel('Stress (MPa)')
ylabel('P-wave modulus (GPa)')
figure(2)
plot(Pd1,D44e)
hold on
plot(Pd11,D44d)
legend('Experiment data','Analytical result')
xlabel('Stress (MPa)')
ylabel('Shear modulus (GPa)')
figure(3)
plot(Pd1,D55e)
hold on
plot(Pd11,D55d)
legend('Experiment data','Analytical result')
xlabel('Stress (MPa)')
ylabel('Shear modulus (GPa)')